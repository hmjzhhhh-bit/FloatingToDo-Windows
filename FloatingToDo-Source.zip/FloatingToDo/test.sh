#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p "${TMPDIR:-/tmp}/FloatingToDo-build"
CACHE="$(cd "${TMPDIR:-/tmp}/FloatingToDo-build" && pwd)/module-cache"
mkdir -p "$CACHE" "${CACHE%/module-cache}/tests"
xcrun swiftc -whole-module-optimization -swift-version 5 -target arm64-apple-macosx12.6 -module-cache-path "$CACHE" -DTESTING Sources/*.swift Tests/CoreTests.swift -o "${CACHE%/module-cache}/tests/FloatingToDoTests"
"${CACHE%/module-cache}/tests/FloatingToDoTests"
plutil -lint Info.plist FloatingToDo.xcodeproj/project.pbxproj
