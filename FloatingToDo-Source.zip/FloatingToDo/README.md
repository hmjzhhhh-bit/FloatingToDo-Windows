# Floating To-Do

A native, offline macOS 12.6+ utility written in SwiftUI and AppKit. No third-party dependencies, accounts, telemetry, network access, or cloud services.

## Run

Open `build/Floating To-Do.app`. The included universal build supports Intel and Apple Silicon Macs.

A 64 pt circular counter and a checklist menu-bar icon appear. Click the counter to morph the same native window into the task panel. The 240 ms transition passes through a small rounded square; Clicking outside the app reverses the same path; X asks for confirmation before quitting. The counter and task panel are never separate floating windows. Drag the counter to move it; drag the narrow strip at the top of the panel to move the panel. Escape closes the active deadline picker first, then its editor or task panel. Clicking another app collapses the panel to its original circle position. The top-right gear opens preferences. Right-click the circle (or use a two-finger trackpad click) to reveal Quit and Quick Add actions; short-click opens the full panel, and dragging still moves the circle. Each tab has a full-width, equal-sized 46 pt hit area. Selected tabs, scroll position and input drafts stay alive through collapse/expansion.

- Enter a title and press Return or click + to add a task.
- Click the calendar to choose an optional deadline. Save sets the deadline; it does not create the task.
- Scroll each time wheel independently, drag it, click a neighboring value, or use Up/Down while focused. Tab changes focus.
- Click a task's title to edit its title and deadline.
- Square checkbox completes; trash moves to Cancelled; restore appends to To-Do.
- In Completed or Cancelled, drag a task title onto the bottom-right trash. The trash grows and darkens while targeted; release to open confirmation. Cancel keeps the task. Restore remains available.
- Drag a To-Do title vertically. The insertion line shows where it will go; release to save the order.
- Overdue rows turn gray within one second while visible and remain interactive.
- The menu-bar menu can show the widget, open the panel, reset its position, optionally enable Launch at Login, or quit.

Launch at Login is off by default. To use it, move the app to a stable location such as `/Applications`, launch that copy, then enable the menu option. On macOS 13+, macOS may request approval in Login Items settings. On macOS 12.6, the menu explains how to add the app manually in System Preferences → Users & Groups → Login Items. Ad-hoc signing is for local use; distribution requires your own Developer ID signing and notarization.

The interface uses installed Courier New Regular (`CourierNewPSMT`) at 110% of the base size, with unchanged PingFang SC Light for Chinese glyphs and a regular system monospaced fallback when unavailable. Preferences provide a 12–22 pt task font size, ±6 pt vertical alignment adjustment, English/Chinese UI, and 12/24-hour time display. No font files are distributed. The native glass uses a lighter white overlay while text stays fully opaque. The application icon has a fixed “3”; the live widget always shows the actual unfinished count.

## Build

With Apple's Command Line Tools or Xcode installed:

```sh
./build.sh
open "build/Floating To-Do.app"
```

The script builds an optimized universal executable (arm64 and x86_64) targeting macOS 12.6, packages the app, and applies an ad-hoc signature. Temporary compiler files live in the system temporary directory.

For Xcode, open `FloatingToDo.xcodeproj`, choose the FloatingToDo scheme and My Mac, then Build or Run. The project uses system frameworks and has no package resolution step. Choose your own signing team for distribution. The Xcode project can also build for an Intel Mac with a suitable destination; the supplied script builds both architectures.

```sh
./test.sh
```

## Source layout

- `App.swift`: lifecycle, menu-bar recovery controls, ServiceManagement login integration.
- `Windows.swift`: one persistent NSPanel, retained SwiftUI content hosts, shared two-stage morph path, native glass and shape masks, screen anchoring, persisted circle coordinates and drag handling.
- `TaskStore.swift`: task schema, atomic JSON transactions, task transitions, manual ordering, deadline formatting.
- `TaskPanel.swift`: tabs, rows, fixed composer, editing and drag/drop.
- `DeadlinePicker.swift`: monthly calendar and transactional deadline selection.
- `TimeWheel.swift`: custom native scrolling, snapping, mouse/keyboard and accessibility controls.
- `Glass.swift`: subtle button feedback and native panel drag surface.
- `Tests/CoreTests.swift`: executable assertions for persistence, lifecycle, failure handling, ordering, overdue logic, wheel accessibility, Escape routing, and native window/menu integration.
- `REFERENCES.md`: GitHub research and provenance.
- `TESTING.md`: actual validation results and remaining checks.

## Storage

Tasks are saved to `~/Library/Application Support/FloatingToDo/tasks.json`. Widget position uses the app's local UserDefaults domain, `com.local.floatingtodo`. Back up the JSON file to preserve task history. Nothing is automatically deleted.

Every successful change is written atomically before publishing the new state. A write failure leaves the previous state intact and shows an error. An unreadable or unsupported file is preserved and blocks writes until repaired and the app restarted.

For isolated testing, launch the executable with `FLOATING_TODO_DATA_FILE` set to an alternative absolute JSON path. This changes task storage only; widget coordinates still use the app defaults.

Reduce Transparency uses an opaque white surface. Reduce Motion switches directly between the exact native window sizes and disables task and wheel snapping animations. The app forces a light appearance to preserve the requested white surfaces and black type.

## Icon artwork

`Resources/AppIcon.icns` is packaged by both build.sh and the Xcode resource phase. The iconset includes 16–1024 pixel artwork. To regenerate it on a Mac with Courier New installed:

```sh
xcrun swift Tools/GenerateIcon.swift Resources
iconutil -c icns Resources/AppIcon.iconset -o Resources/AppIcon.icns
./build.sh
```

The source draws clean circular artwork and a font glyph; it does not crop the screenshot.

Version 1.2.0: Quick Add supports a deadline calendar. Settings include Songti, Fangsong, Kaiti, and PingFang Light presets with mixed Chinese/English previews. The installed app lives only in /Applications/Floating To-Do.app. Old versions are compressed in Archive; source build products are not retained after installation.

Version 1.3.0: Chinese is fixed to PingFang SC Light; font preset controls are removed. Dragging uses stable panel coordinates and a separate non-interactive preview. A single drag can move any row directly to the first or last position; edge scrolling supports longer lists. Archived tasks can be dropped on the footer trash, with scale/darkening feedback and confirmation before permanent deletion.

## Version 1.3.2

In Completed and Cancelled, drag from blank list space to marquee-select tasks. Selected rows are highlighted; drag a selected task to the footer trash to delete the group after one confirmation. Dragging an unselected task starts a new single-task group. Clicking blank space or changing tabs clears selection. Active to-do sorting is unchanged.
