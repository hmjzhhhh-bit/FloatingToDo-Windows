# Technical references

Reviewed before implementation on October 27, 2026. No source code, assets, or dependencies were imported from these projects; all application code here is original.

- [FloatingPanel](https://github.com/disc0infern0/FloatingPanel): SwiftUI content in movable native macOS panels; reference for NSPanel-based window architecture.
- [MenuBarExtraAccess](https://github.com/orchetect/MenuBarExtraAccess): menu-bar visibility and underlying status-item control. This app uses NSStatusItem directly for its small recovery menu.
- [SwiftUI Reorderable ForEach](https://github.com/globulus/swiftui-reorderable-foreach): order handling in SwiftUI stacks. The final app uses a direct vertical drag gesture, a moving row preview and insertion feedback, then saves the order on release.
- [todomenu](https://github.com/mylovelytools/todomenu): lightweight SwiftUI/AppKit to-do architecture and atomic JSON persistence. Its AGPL code was not copied or linked.
- [SwiftUIWheelPicker](https://github.com/GGJJack/SwiftUIWheelPicker): centered selection, faded neighboring values, and snapping. Its picker is horizontal; this app implements original vertical AppKit controls for macOS scroll events and keyboard access.
- [Apple MenuBarExtra documentation](https://developer.apple.com/documentation/swiftui/menubarextra): native menu-bar integration options.

The supplied product specification controls this app's interface and behavior.
