import Foundation
import AppKit

@main struct CoreTests {
    @MainActor static func main() throws {
        let keys = ["language", "hour24", "taskSize", "textOffset", "chineseFont"]
        let saved = keys.map { UserDefaults.standard.object(forKey: $0) }
        defer { for (key, value) in zip(keys, saved) { if let value { UserDefaults.standard.set(value, forKey: key) } else { UserDefaults.standard.removeObject(forKey: key) } } }
        UserDefaults.standard.set("en", forKey: "language")
        UserDefaults.standard.set(false, forKey: "hour24")
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("FloatingTodoTests-\(UUID())")
        defer { try? FileManager.default.removeItem(at: folder) }
        let url = folder.appendingPathComponent("tasks.json")
        let store = TaskStore(url: url)
        assert(store.count == 0)
        assert(!store.add(" \n ", deadline: nil))
        let deadline = Date(timeIntervalSince1970: 1793313000)
        assert(store.add("  First  ", deadline: deadline))
        assert(store.add("Second", deadline: nil))
        assert(store.add("Third", deadline: nil))
        let first = store.items(.todo)[0].id; let second = store.items(.todo)[1].id; let third = store.items(.todo)[2].id
        assert(store.items(.todo)[0].title == "First")
        assert(store.count == 3)
        store.move(third, before: first)
        assert(store.items(.todo).map(\.id) == [third, first, second])
        assert(TaskStore(url: url).items(.todo).map(\.id) == [third, first, second])
        store.move(third, before: nil)
        assert(store.items(.todo).map(\.id) == [first, second, third])
        store.transition(first, to: .completed, now: deadline)
        assert(store.count == 2 && store.items(.completed)[0].completedAt == deadline)
        store.transition(second, to: .cancelled, now: deadline)
        assert(store.count == 1 && store.items(.cancelled)[0].cancelledAt == deadline)
        store.transition(first, to: .todo)
        store.transition(second, to: .todo)
        assert(store.items(.todo).map(\.id) == [third, first, second])
        assert(store.items(.todo)[1].deadline == deadline)
        assert(store.items(.todo)[1].completedAt == nil)
        assert(store.edit(first, title: "Renamed", deadline: deadline))
        assert(!store.edit(first, title: "  ", deadline: nil))
        let task = store.items(.todo)[1]
        assert(!task.isOverdue(at: deadline.addingTimeInterval(-1)))
        assert(task.isOverdue(at: deadline.addingTimeInterval(1)))
        assert(!store.items(.todo)[0].isOverdue(at: Date.distantFuture))
        assert(TaskStore(url: url).tasks == store.tasks)
        assert(DeadlineText.string(deadline).contains("AM") || DeadlineText.string(deadline).contains("PM"))
        assert(store.edit(first, title: "Renamed", deadline: nil))
        assert(TaskStore(url: url).items(.todo)[1].deadline == nil)
        let before = store.tasks
        store.move(UUID(), before: nil); store.move(first, before: UUID())
        assert(store.tasks == before)
        // A disconnected display and negative monitor origins both recover inside the visible area.
        let visible = NSRect(x: -1920, y: 30, width: 1920, height: 1050)
        let clamped = WindowGeometry.clamp(NSRect(x: 9000, y: -800, width: 64, height: 64), to: visible)
        assert(visible.contains(clamped))
        assert(WindowGeometry.clamp(NSRect(x: -3000, y: 2000, width: 400, height: 460), to: visible).maxY == visible.maxY)
        assert(visible.contains(WindowGeometry.clamp(NSRect(x: 0, y: 0, width: 4000, height: 4000), to: visible)))
        let corrupt = folder.appendingPathComponent("corrupt.json")
        try Data("not json".utf8).write(to: corrupt)
        let damaged = TaskStore(url: corrupt)
        assert(damaged.error != nil && !damaged.add("Must not overwrite", deadline: nil))
        let preserved = try String(contentsOf: corrupt)
        assert(preserved == "not json")
        let badURL = url.appendingPathComponent("impossible.json")
        let unwritable = TaskStore(url: badURL)
        assert(!unwritable.add("Failure", deadline: nil) && unwritable.tasks.isEmpty && unwritable.error != nil)
        let wheel = WheelView(frame: NSRect(x: 0, y: 0, width: 60, height: 126)); wheel.values = ["AM", "PM"]
        wheel.select(100); assert(wheel.selected == 1)
        wheel.select(-100); assert(wheel.selected == 0)
        assert(wheel.accessibilityPerformIncrement() && wheel.selected == 1)
        assert(wheel.accessibilityPerformDecrement() && wheel.selected == 0)
        DeadlinePopoverState.isVisible = true
        assert(DeadlinePopoverState.blocksParentEscape)
        DeadlinePopoverState.isVisible = false; DeadlinePopoverState.lastClosed = Date()
        assert(DeadlinePopoverState.blocksParentEscape)
        DeadlinePopoverState.lastClosed = .distantPast
        assert(!DeadlinePopoverState.blocksParentEscape)
        let archiveURL = folder.appendingPathComponent("archive-tests.json")
        let archives = TaskStore(url: archiveURL)
        for title in ["Active", "Completed delete", "Completed keep", "Cancelled delete", "Cancelled keep"] { assert(archives.add(title, deadline: deadline)) }
        let ids = archives.items(.todo).map(\.id)
        archives.transition(ids[1], to: .completed); archives.transition(ids[2], to: .completed)
        archives.transition(ids[3], to: .cancelled); archives.transition(ids[4], to: .cancelled)
        let beforeDelete = archives.tasks
        assert(!archives.deleteArchived([ids[0]], from: .todo))
        assert(!archives.deleteArchived([], from: .completed))
        assert(archives.tasks == beforeDelete)
        assert(archives.deleteArchived([ids[0], ids[1], ids[3]], from: .completed))
        assert(archives.count == 1 && archives.items(.completed).map(\.id) == [ids[2]])
        assert(archives.items(.cancelled).count == 2)
        assert(TaskStore(url: archiveURL).tasks == archives.tasks)
        assert(archives.deleteArchived([ids[0], ids[2], ids[3]], from: .cancelled))
        assert(archives.count == 1 && archives.items(.cancelled).map(\.id) == [ids[4]])
        assert(archives.items(.completed).map(\.id) == [ids[2]])
        archives.transition(ids[4], to: .todo)
        assert(!archives.deleteArchived([ids[4]], from: .cancelled))
        assert(archives.count == 2)
        assert(TaskStore(url: archiveURL).tasks == archives.tasks)
        assert(AppTypography.native(26).fontName == "CourierNewPSMT")
        assert(abs(AppTypography.native(26).pointSize - 28.6) < 0.01)
        let selectionA = UUID(), selectionB = UUID()
        let selectionFrames = [selectionA: CGRect(x: 10, y: 10, width: 100, height: 30), selectionB: CGRect(x: 10, y: 50, width: 100, height: 30)]
        assert(ArchiveSelection.ids(in: ArchiveSelection.rect(CGPoint(x: 120,y: 90),CGPoint(x: 0,y: 0)), frames: selectionFrames) == [selectionA, selectionB])
        assert(ArchiveSelection.ids(in: CGRect(x: 0,y: 0,width: 50,height: 45), frames: selectionFrames) == [selectionA])
        assert(ArchiveSelection.ids(in: .zero, frames: selectionFrames).isEmpty)
        let groups = TaskStore(url: folder.appendingPathComponent("groups.json"))
        for title in ["A","B","C","D","E"] { assert(groups.add(title, deadline: deadline)) }
        let groupIDs = groups.items(.todo).map(\.id)
        groups.move([groupIDs[3],groupIDs[4]], before: groupIDs[0])
        assert(groups.items(.todo).map(\.title) == ["D","E","A","B","C"])
        groups.move([groupIDs[3],groupIDs[0]], before: nil)
        assert(groups.items(.todo).map(\.title) == ["E","B","C","D","A"])
        groups.cancel([groupIDs[0],groupIDs[3]])
        assert(groups.items(.todo).map(\.title) == ["E","B","C"])
        assert(groups.items(.cancelled).map(\.title) == ["D","A"])
        assert(groups.items(.cancelled).allSatisfy { $0.deadline == deadline })
        assert(TaskStore(url: folder.appendingPathComponent("groups.json")).tasks == groups.tasks)
        let savedPosition = UserDefaults.standard.object(forKey: "widgetPosition")
        defer {
            if let savedPosition { UserDefaults.standard.set(savedPosition, forKey: "widgetPosition") }
            else { UserDefaults.standard.removeObject(forKey: "widgetPosition") }
        }
        let screenBounds = NSRect(x: -1920, y: 30, width: 1920, height: 1050)
        for origin in [NSPoint(x: -1912, y: 38), NSPoint(x: -72, y: 38), NSPoint(x: -1912, y: 1008), NSPoint(x: -72, y: 1008), NSPoint(x: -960, y: 530)] {
            let circle = NSRect(origin: origin, size: NSSize(width: 64, height: 64))
            let expanded = WindowGeometry.expanded(from: circle, within: screenBounds)
            assert(screenBounds.contains(expanded))
            let initial = MorphGeometry.sample(progress: 0, circle: circle, expanded: expanded)
            let square = MorphGeometry.sample(progress: 50.0 / 240.0, circle: circle, expanded: expanded)
            let final = MorphGeometry.sample(progress: 1, circle: circle, expanded: expanded)
            assert(initial.frame == circle && initial.radius == 32 && initial.counterOpacity == 1)
            assert(square.frame == circle && square.radius == 16 && square.contentOpacity == 0)
            assert(final.frame == expanded && final.radius == 20 && final.counterOpacity == 0 && final.contentOpacity == 1)
            for step in 0...24 {
                let sample = MorphGeometry.sample(progress: CGFloat(step) / 24, circle: circle, expanded: expanded)
                assert(screenBounds.contains(sample.frame))
                assert(sample.counterOpacity == 0 || sample.contentOpacity == 0)
            }
        }
        UserDefaults.standard.set(true, forKey: "hour24")
        assert(!DeadlineText.string(deadline).contains("PM") && !DeadlineText.string(deadline).contains("AM"))
        UserDefaults.standard.set("zh", forKey: "language")
        assert(TaskStatus.completed.label == "已完成" && DeadlineText.string(deadline).contains("年"))
        UserDefaults.standard.set("en", forKey: "language")
        UserDefaults.standard.set(false, forKey: "hour24")
        UserDefaults.standard.set("STKaiti", forKey: "chineseFont")
        assert(Preferences.chineseFont == "PingFangSC-Light")
        assert(NSFont(name: Preferences.chineseFont, size: 14) != nil)
        do {
        let reorder = TaskStore(url: folder.appendingPathComponent("reorder.json"))
        for title in ["One", "Two", "Three", "Four"] { assert(reorder.add(title, deadline: nil)) }
        let ids = reorder.items(.todo).map(\.id)
        let frames = Dictionary(uniqueKeysWithValues: ids.enumerated().map { ($0.element, CGRect(x: 0, y: 80 + $0.offset * 60, width: 360, height: 60)) })
        let firstTarget = DragPlacement.target(id: ids[3], y: 90, ordered: ids, frames: frames)
        assert(firstTarget == ids[0])
        reorder.move(ids[3], before: firstTarget)
        assert(reorder.items(.todo).map(\.title) == ["Four", "One", "Two", "Three"])
        assert(TaskStore(url: folder.appendingPathComponent("reorder.json")).items(.todo).map(\.id).first == ids[3])
        assert(DragPlacement.target(id: ids[0], y: 500, ordered: ids, frames: frames) == nil)
        assert(DragPlacement.target(id: ids[3], y: 190, ordered: ids, frames: frames) == ids[2])
        }
        _ = NSApplication.shared
        let interaction = WidgetInteraction.InteractionView()
        var clicks = 0; var menus = 0
        interaction.open = { clicks += 1 }; interaction.contextAction = { menus += 1 }
        let secondary = NSEvent.mouseEvent(with: .rightMouseDown, location: .zero, modifierFlags: [], timestamp: 0, windowNumber: 0, context: nil, eventNumber: 0, clickCount: 1, pressure: 1)!
        interaction.rightMouseDown(with: secondary)
        assert(menus == 1 && clicks == 0)
        let primary = NSEvent.mouseEvent(with: .leftMouseDown, location: .zero, modifierFlags: [], timestamp: 0, windowNumber: 0, context: nil, eventNumber: 0, clickCount: 1, pressure: 1)!
        interaction.mouseDown(with: primary)
        RunLoop.main.run(until: Date().addingTimeInterval(0.6))
        assert(menus == 1)
        interaction.mouseUp(with: primary)
        assert(clicks == 1)

        setenv("FLOATING_TODO_DATA_FILE", folder.appendingPathComponent("window-tests.json").path, 1)
        let delegate = AppDelegate()
        delegate.applicationDidFinishLaunching(Notification(name: NSApplication.didFinishLaunchingNotification))
        let menu = delegate.statusItem.menu!
        let loginTitle: String
        if #available(macOS 13, *) { loginTitle = "Launch at Login" } else { loginTitle = "Launch at Login Settings…" }
        assert(menu.items.map(\.title).filter { !$0.isEmpty } == ["Show Floating Widget", "Open To-Do", "Reset Widget Position", loginTitle, "Quit Floating To-Do"])
        delegate.menuWillOpen(menu)
        let controller = delegate.controller!
        let identity = controller.window.windowNumber
        assert(NSApp.windows.filter { $0 is FloatingPanel }.count == 1)
        assert(controller.window.isVisible && controller.window.frame.size == NSSize(width: 64, height: 64))
        assert(controller.window.collectionBehavior.contains(.stationary))
        assert(controller.window.level == .floating && controller.window.collectionBehavior.contains(.canJoinAllSpaces))
        controller.window.setFrameOrigin(NSPoint(x: 90000, y: -90000))
        RunLoop.main.run(until: Date().addingTimeInterval(0.02))
        menu.performActionForItem(at: 0)
        assert(NSScreen.screens.contains { $0.visibleFrame.contains(controller.window.frame) })
        let originalCircle = controller.window.frame
        menu.performActionForItem(at: 1)
        var frames: [NSRect] = []
        for _ in 0..<20 {
            RunLoop.main.run(until: Date().addingTimeInterval(0.016))
            frames.append(controller.window.frame)
            assert(controller.window.windowNumber == identity)
            assert(NSApp.windows.filter { $0 is FloatingPanel }.count == 1)
        }
        assert(controller.progress == 1 && !controller.isAnimating)
        assert(frames.contains { $0.width > 64 && $0.width < 400 })
        assert(controller.window.frame == controller.expandedFrame)
        controller.closePanel()
        RunLoop.main.run(until: Date().addingTimeInterval(0.3))
        assert(controller.window.frame == originalCircle && controller.progress == 0)
        assert(controller.window.isVisible && controller.window.windowNumber == identity)
        // Reverse twice without allocating a new window or jumping to either endpoint.
        controller.openPanel()
        RunLoop.main.run(until: Date().addingTimeInterval(0.09))
        let partial = controller.progress
        controller.closePanel()
        assert(controller.progress == partial)
        RunLoop.main.run(until: Date().addingTimeInterval(0.025))
        controller.openPanel()
        RunLoop.main.run(until: Date().addingTimeInterval(0.3))
        assert(controller.progress == 1 && controller.window.frame == controller.expandedFrame)
        controller.setExpanded(false, animated: false)
        assert(controller.window.frame == originalCircle)
        controller.setExpanded(true, animated: false)
        assert(controller.window.frame == controller.expandedFrame)
        let draggedOrigin = NSPoint(x: controller.window.frame.minX - 20, y: controller.window.frame.minY - 20)
        controller.window.setFrameOrigin(draggedOrigin)
        RunLoop.main.run(until: Date().addingTimeInterval(0.02))
        controller.setExpanded(false, animated: false)
        assert(abs(controller.window.frame.minX - (originalCircle.minX - 20)) < 1)
        assert(abs(controller.window.frame.minY - (originalCircle.minY - 20)) < 1)
        controller.openPanel()
        controller.recoverWindows()
        assert(controller.progress == 1 && !controller.isAnimating)
        menu.performActionForItem(at: 2)
        assert(controller.progress == 0 && controller.window.frame.size == NSSize(width: 64, height: 64))
        assert(NSScreen.screens.first!.visibleFrame.contains(controller.window.frame))
        assert(controller.window.windowNumber == identity)
        controller.setExpanded(true, animated: false)
        controller.dismissOutside()
        RunLoop.main.run(until: Date().addingTimeInterval(0.3))
        assert(controller.progress == 0)
        controller.showQuickActions()
        RunLoop.main.run(until: Date().addingTimeInterval(0.3))
        assert(NSApp.windows.filter { $0 is FloatingPanel && $0.isVisible }.count == 3)
        controller.showQuickInput()
        assert(NSApp.windows.filter { $0 is FloatingPanel && $0.isVisible }.count == 2)
        controller.dismissOutside()
        assert(NSApp.windows.filter { $0 is FloatingPanel && $0.isVisible }.count == 1)
        controller.window.orderOut(nil)
        NSStatusBar.system.removeStatusItem(delegate.statusItem)
        print("PASS: task regressions, morph geometry, single-window identity, actual animated bounds, reversals, anchors and menu recovery")
    }
}
