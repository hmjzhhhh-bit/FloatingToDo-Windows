import AppKit
import CoreText

let root = URL(fileURLWithPath: CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "Resources")
let iconset = root.appendingPathComponent("AppIcon.iconset")
try FileManager.default.createDirectory(at: iconset, withIntermediateDirectories: true)
guard let font = NSFont(name: "CourierNewPSMT", size: 400) else { fatalError("Courier New must be installed to regenerate the icon.") }
let ctFont = CTFontCreateWithName(font.fontName as CFString, 400, nil)
var character: UniChar = 51
var glyph: CGGlyph = 0
CTFontGetGlyphsForCharacters(ctFont, &character, &glyph, 1)
let numeral = CTFontCreatePathForGlyph(ctFont, glyph, nil)!
for (name, pixels) in [("icon_16x16.png",16), ("icon_16x16@2x.png",32), ("icon_32x32.png",32), ("icon_32x32@2x.png",64), ("icon_128x128.png",128), ("icon_128x128@2x.png",256), ("icon_256x256.png",256), ("icon_256x256@2x.png",512), ("icon_512x512.png",512), ("icon_512x512@2x.png",1024)] {
    let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: pixels, pixelsHigh: pixels, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
    let context = NSGraphicsContext(bitmapImageRep: bitmap)!.cgContext
    context.scaleBy(x: CGFloat(pixels) / 1024, y: CGFloat(pixels) / 1024)
    let circle = CGRect(x: 80, y: 92, width: 864, height: 864)
    context.saveGState()
    context.setShadow(offset: CGSize(width: 0, height: -12), blur: 26, color: CGColor(gray: 0, alpha: 0.18))
    context.setFillColor(CGColor(gray: 0.93, alpha: 1)); context.fillEllipse(in: circle)
    context.restoreGState()
    context.setStrokeColor(CGColor(gray: 0.70, alpha: 0.7)); context.setLineWidth(2.5); context.strokeEllipse(in: circle.insetBy(dx: 1.25, dy: 1.25))
    let box = numeral.boundingBoxOfPath
    context.translateBy(x: circle.midX - box.midX, y: circle.midY - box.midY)
    context.addPath(numeral); context.setFillColor(CGColor(gray: 0.22, alpha: 1)); context.fillPath()
    let png = bitmap.representation(using: .png, properties: [:])!
    try png.write(to: iconset.appendingPathComponent(name))
    if pixels == 1024 { try png.write(to: root.appendingPathComponent("AppIcon.png")) }
}
print("Generated Courier New icon artwork at \(root.path)")
