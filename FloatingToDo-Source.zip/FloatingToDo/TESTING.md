# Validation

Tested October 27, 2026 on an Apple Silicon Mac using Apple Swift 6.3.3 and the macOS SDK from Command Line Tools. Deployment target: macOS 14. No external dependencies.

## Archive deletion, Courier New and icon update

Verified in this update:

- Optimized app build, complete automated regression suite, plist/project validation, and strict code-signature verification passed.
- Selective deletion in each archive preserves unselected items, the other archive and all active tasks. Active-category deletion is rejected. Deleted records stay absent after reopening the store; unfinished counts remain unchanged.
- A restored task cannot be deleted using a stale archive selection.
- Live selection controls worked in both archives. The Cancelled confirmation displayed the selected count and irreversibility warning. Cancelling preserved all 18 fixture records. Actual permanent deletion was exercised through model tests, not the final GUI confirmation button.
- CourierNewPSMT is installed and resolves to Courier New Regular. Screenshots inspected tabs, long two-line titles, dates, input, calendar, wheel labels/values and a centered two-digit counter.
- Native glass now uses HUD material and a 10% white overlay. Text and window opacity were not reduced. The opaque Reduce Transparency fallback remains implemented.
- The app bundle contains AppIcon.icns and CFBundleIconFile=AppIcon. All ICNS chunks parsed correctly, including small and Retina resolutions. LSUIElement remains enabled. The Xcode resource phase references the same icon.
- The user's normal task JSON matched its pre-change SHA-256 checksum after testing. UI fixtures were stored separately.

Not verified in this update: deliberate side-by-side light/dark desktop comparisons, Launchpad/Finder icon cache refresh, and visual inspection of every editing state. Full Xcode builds and global accessibility-setting changes remain untested as detailed below.

## Unified-window refinement

The existing project was refined in place. The persistent data format remains unchanged. TaskStore now also supports atomic selective archive deletion. Live regression tests used separate fixture files, not the normal task file.

Verified in the refined build:

- One persistent FloatingPanel instance and windowNumber during expansion, collapse and rapid reversals.
- Actual native window-frame samples include intermediate sizes and finish at 64 × 64 pt or the screen-clamped panel target.
- A 50 ms circle-to-square stage plus 190 ms expansion; closing follows the same path in reverse. Counter and task-content opacity never overlap.
- Exact return to the collapsed anchor, including translated anchors after dragging the expanded panel.
- Geometry samples stay within simulated display bounds at all four corners and the center, including negative monitor coordinates.
- Recovery during a running transition cancels the timer and settles to a valid single-window state.
- Nonanimated transitions use the same exact geometry endpoints (the Reduce Motion path).
- Live screenshots show a circular 64 pt silhouette, light charcoal typography and a centered three-digit counter (123).
- Blank-space clicks in the left, middle and right navigation regions activate the corresponding tab.
- X collapses the same window; reopening retains the selected tab and unfinished input draft.
- Live regression checks passed for creation, completion, restoration, cancellation, title/deadline editing, overdue styling and vertical reordering. All three wheel values were changed through their accessibility actions.
- Persistence and corrupt-file protection remain covered by the regression suite.

Animations were checked through native frame samples and live open/close interactions. Physical multi-monitor disconnection, all display refresh rates, and global accessibility preference changes were not exercised.

## Automated

`./test.sh` compiles and runs the task and native-window assertion suite covering:

- Empty and whitespace-only title rejection; title trimming and editing.
- Add, complete, cancel, restore, unfinished count and transition timestamps.
- Restoration to the bottom with original deadlines retained.
- Move before another task, move to bottom, invalid move rejection.
- JSON round-trip persistence of task data and custom ordering.
- Deadline removal and overdue boundary behavior.
- Corrupt data preservation and failed-write rollback.
- Window clamping with disconnected-display coordinates, negative display origins and oversized frames.
- Wheel selection bounds and accessibility increment/decrement.
- Escape propagation guards for active/recently dismissed date pickers.
- Actual NSStatusItem menu titles and Show/Open/Reset action dispatch.
- Actual floating window visibility, 64 pt diameter, window level, Spaces flags, compact panel sizing, single-window morph identity, rapid reversals, anchoring and recovery from off-screen coordinates.

The native integration tests require a logged-in macOS desktop. They briefly create windows, use temporary task data, and reset this app's widget position. They do not enable Launch at Login.

`build.sh` produced the standalone arm64 application. `codesign --verify --deep --strict` passed. Both Info.plist and the Xcode project passed `plutil -lint`.

## Live UI checks

Used the compiled standalone application with an isolated task-data file:

- Counter opens the compact panel; native materials, rounded surfaces, typography and layout inspected in screenshots.
- Created tasks with Return and +, including one with a saved deadline.
- Saving a deadline did not create the task prematurely.
- Completed, cancelled and restored tasks through the three tabs.
- Edited a title and deadline; inspected the muted styling of every control on an overdue row.
- Navigated previous/next calendar months and selected past/future dates.
- Scrolled hour, minute and AM/PM independently; changed hour with the keyboard.
- Cleared a saved deadline through the editor.
- Dragged a task above another task and verified the resulting order.
- Relaunched and verified count, edited title, deadline and manual order persisted.
- Dragged the circular widget without opening its panel.
- Closed the task panel with Escape; verified that Escape first dismisses the date picker while preserving the panel or nested editor.
- Observed a task change from normal text to muted gray automatically when its deadline passed during the running session.
- Inspected wheel clipping and monochrome keyboard-focus styling after fixes.

## Remaining environment checks

- Full Xcode is not installed here. The project is provided and syntax-validated; its source was built with Apple's command-line compiler, not through Xcode's UI or xcodebuild.
- No physical monitor was disconnected, no macOS restart was performed, and full-screen Spaces transitions were not exercised. Screen-recovery math and native recovery actions were tested.
- Launch at Login uses SMAppService, remains off, and was not registered or tested across login. Enable it only after moving the app to a stable location; system approval may be required.
- Reduce Transparency and Reduce Motion are implemented using system accessibility state. Global user settings were not changed for testing.
- The app targets macOS 14+ but was not run on a separate macOS 14 machine or Intel Mac.
- The bundle is ad-hoc signed for local use, not Developer ID signed or notarized for public distribution.

## macOS Monterey compatibility update — October 27, 2026

- Deployment target is now macOS 12.6 in Info.plist, Xcode, build.sh and test.sh.
- Built optimized arm64 and x86_64 slices and combined them into a universal app. Both slices declare minimum macOS 12.6; ad-hoc signature verified.
- Replaced newer task change callback and keyboard APIs with Monterey-compatible equivalents; older systems use TextEditor for multiline editing. Newer hosting sizing and SMAppService calls are availability-guarded.
- On macOS 12.6, Launch at Login Settings explains the manual Login Items procedure and opens System Preferences. macOS 13+ retains the existing toggle.
- Full existing regression suite passed on the current Apple Silicon macOS 26.6.2 host, including persistence, archive deletion, native animated bounds, reversal, single-window identity, and menu recovery. Tests use temporary task files.
- Not run on physical Intel hardware or macOS 12.6. Monterey editor rendering, native button drag/keyboard behavior, and manual Login Items require trial on that system. The app remains ad-hoc signed and unnotarized.

## Settings and quick actions update

- Universal macOS 12.6 build and signature verification passed.
- Native regression suite passed, including language/time formatting, outside-dismiss state transitions, quick-action windows, quick-input window lifecycle, and the existing storage and morph tests.
- Inspected the running app: gear popover, Chinese labels, Courier New + Songti SC mixed text preview, black controls. Settings screenshot saved with the deliverable.
- Actual macOS 12.6/Intel runtime and multi-monitor quick-menu edge behavior remain unverified. Long-press expansion is implemented with a 0.5-second hold and movement cancellation; the auxiliary windows were checked in native tests, but full end-to-end pointer interactions were not exhaustively tested.

## Version 1.2.0

Universal build and native regressions passed. Added direct event tests for right-click versus left-click/hold and font fallback. Verified all four installed font presets in the actual settings popover and verified X opens confirmation with Cancel leaving the app alive. Quick Add reuses the existing deadline picker and passes the selected date to atomic task storage. macOS 12.6/Intel physical hardware remains untested.

## Version 1.3.0

Universal compilation and regression suite passed. Added fourth-to-first direct reorder and persistence assertions, intermediate/end target calculations, and fixed PingFang font verification. Existing archive-delete safety checks remain passing. The updated app was launched with existing data; final manual drag/hover checks were limited by repeated computer-use interruptions. macOS 12.6 and physical Intel hardware remain unverified.
