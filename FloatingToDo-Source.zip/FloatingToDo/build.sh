#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
APP="build/Floating To-Do.app"
mkdir -p "${TMPDIR:-/tmp}/FloatingToDo-build"
CACHE="$(cd "${TMPDIR:-/tmp}/FloatingToDo-build" && pwd)/module-cache"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources" "$CACHE"
for ARCH in arm64 x86_64; do
    xcrun swiftc -whole-module-optimization -swift-version 5 -O -target "$ARCH-apple-macosx12.6" -module-cache-path "$CACHE" Sources/*.swift -o "${CACHE%/module-cache}/FloatingToDo-$ARCH"
done
xcrun lipo -create "${CACHE%/module-cache}/FloatingToDo-arm64" "${CACHE%/module-cache}/FloatingToDo-x86_64" -output "$APP/Contents/MacOS/FloatingToDo"
cp Resources/AppIcon.icns "$APP/Contents/Resources/AppIcon.icns"
cp Info.plist "$APP/Contents/Info.plist"
codesign --force --sign - "$APP"
printf 'Built %s\n' "$PWD/$APP"
