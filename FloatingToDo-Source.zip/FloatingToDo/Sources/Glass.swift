import SwiftUI
import AppKit

enum AppTypography {
    static func native(_ size: CGFloat) -> NSFont {
        let base = NSFont(name: "CourierNewPSMT", size: size * 1.10) ?? NSFont.monospacedSystemFont(ofSize: size * 1.10, weight: .regular)
        let chinese = NSFontDescriptor(name: Preferences.chineseFont, size: size)
        return NSFont(descriptor: base.fontDescriptor.addingAttributes([.cascadeList: [chinese]]), size: size * 1.10) ?? base
    }
    static func font(_ size: CGFloat) -> Font { Font(native(size)) }
}

struct QuietButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        QuietButtonBody(configuration: configuration)
    }
    private struct QuietButtonBody: View {
        let configuration: ButtonStyle.Configuration
        @Environment(\.accessibilityReduceMotion) private var reduceMotion
        @State private var hover = false
        var body: some View {
            configuration.label.padding(5).contentShape(Rectangle())
                .background(Color.black.opacity(configuration.isPressed ? 0.09 : hover ? 0.045 : 0), in: RoundedRectangle(cornerRadius: 5))
                .onHover { value in withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.15)) { hover = value } }
        }
    }
}
struct WindowDragArea: NSViewRepresentable {
    func makeNSView(context: Context) -> DragView { DragView() }
    func updateNSView(_ view: DragView, context: Context) {}
    final class DragView: NSView {
        override func mouseDown(with event: NSEvent) { window?.performDrag(with: event) }
    }
}


enum Preferences {
    static let chineseFont = "PingFangSC-Light"
    static var chinese: Bool { UserDefaults.standard.string(forKey: "language") == "zh" }
    static var hour24: Bool { UserDefaults.standard.bool(forKey: "hour24") }
    static var taskSize: CGFloat { let v = UserDefaults.standard.double(forKey: "taskSize"); return v == 0 ? 14 : min(22, max(12, v)) }
    static var textOffset: CGFloat { min(6, max(-6, UserDefaults.standard.double(forKey: "textOffset"))) }
    static var locale: Locale { Locale(identifier: chinese ? "zh_CN" : "en_US") }
}
func L(_ english: String, _ chinese: String) -> String { Preferences.chinese ? chinese : english }

struct PreferencesView: View {
    @AppStorage("taskSize") private var size = 14.0
    @AppStorage("textOffset") private var offset = 0.0
    @AppStorage("language") private var language = "en"
    @AppStorage("hour24") private var hour24 = false
    var body: some View {
        ScrollView {
        VStack(alignment: .leading, spacing: 14) {
            Text(L("Settings", "设置")).font(AppTypography.font(17))
            Text(L("Task font size", "待办字体大小") + "  \(Int(size))")
            Slider(value: $size, in: 12...22, step: 1)
            Text(L("Text vertical alignment", "文字上下微调") + "  \(Int(offset))")
            Slider(value: $offset, in: -6...6, step: 1)
            HStack(spacing: 10) {
                Image(systemName: "square").font(.system(size: 16, weight: .light))
                mixedText("待办 To-do", size: size).offset(y: offset)
            }.frame(height: 34)
            Picker(L("Language", "语言"), selection: $language) {
                Text("English").tag("en"); Text("中文").tag("zh")
            }
            Picker(L("Time format", "时间格式"), selection: $hour24) {
                Text("AM / PM").tag(false); Text(L("24-hour", "24 小时制")).tag(true)
            }
            Button(L("Reset appearance", "重置字体与对齐")) { size = 14; offset = 0 }
        }.font(AppTypography.font(13)).foregroundColor(.black).padding(20)
        }.frame(width: 320, height: 350)
            .preferredColorScheme(.light).tint(.black)
    }
}

// SwiftUI's Font(NSFont) drops the cascade list on some systems; select each script explicitly.
func mixedText(_ string: String, size: CGFloat, chineseFont: String = Preferences.chineseFont) -> Text {
    string.reduce(Text("")) { result, character in
        let cjk = character.unicodeScalars.contains { $0.value >= 0x2E80 && $0.value <= 0xFFFF }
        let font = cjk ? Font.custom(chineseFont, size: size) : AppTypography.font(size)
        return result + Text(String(character)).font(font)
    }
}
