import Foundation
import Combine

 enum TaskStatus: String, Codable, CaseIterable {
    case todo, completed, cancelled
    var label: String { switch self { case .todo: return L("To-Do", "待办"); case .completed: return L("Completed", "已完成"); case .cancelled: return L("Cancelled", "已取消") } }
    var empty: String { switch self { case .todo: return L("Nothing to do.", "暂无待办。"); case .completed: return L("No completed tasks.", "暂无已完成待办。"); case .cancelled: return L("No cancelled tasks.", "暂无已取消待办。") } }
}
struct TodoTask: Identifiable, Codable, Equatable {
    var id = UUID()
    var title: String
    var status: TaskStatus = .todo
    var deadline: Date?
    var createdAt = Date()
    var completedAt: Date?
    var cancelledAt: Date?
    var position: Int
    func isOverdue(at date: Date) -> Bool { status == .todo && deadline.map { $0 < date } == true }
}
struct StoredState: Codable {
    var version = 1
    var tasks: [TodoTask] = []
}
@MainActor final class TaskStore: ObservableObject {
    @Published private(set) var tasks: [TodoTask] = []
    @Published var error: String?
    private let url: URL
    private var loadFailed = false
    init(url: URL? = nil) {
        self.url = url ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("FloatingToDo/tasks.json")
        do {
            if FileManager.default.fileExists(atPath: self.url.path) {
                let state = try JSONDecoder().decode(StoredState.self, from: Data(contentsOf: self.url))
                guard state.version == 1, Set(state.tasks.map(\.id)).count == state.tasks.count else {
                    throw CocoaError(.fileReadCorruptFile)
                }
                tasks = state.tasks
            }
        } catch {
            loadFailed = true
            self.error = "Could not read saved tasks. The original file has been preserved at \(self.url.path). \(error.localizedDescription)"
        }
    }
    var count: Int { tasks.filter { $0.status == .todo }.count }
    func items(_ status: TaskStatus) -> [TodoTask] {
        tasks.filter { $0.status == status }.sorted { $0.position == $1.position ? $0.createdAt < $1.createdAt : $0.position < $1.position }
    }
    @discardableResult private func commit(_ next: [TodoTask]) -> Bool {
        guard !loadFailed else { error = "Saved tasks could not be loaded. Restore the data file and relaunch before making changes."; return false }
        do {
            try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            try encoder.encode(StoredState(tasks: next)).write(to: url, options: .atomic)
            tasks = next
            return true
        } catch { self.error = "Could not save tasks. Your change was not applied. \(error.localizedDescription)"; return false }
    }
    @discardableResult func add(_ title: String, deadline: Date?) -> Bool {
        let clean = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return false }
        return commit(tasks + [TodoTask(title: clean, deadline: deadline, position: nextPosition(.todo))])
    }
    private func nextPosition(_ status: TaskStatus) -> Int { (tasks.filter { $0.status == status }.map(\.position).max() ?? -1) + 1 }
    @discardableResult func edit(_ id: UUID, title: String, deadline: Date?) -> Bool {
        let clean = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, let i = tasks.firstIndex(where: { $0.id == id }) else { return false }
        var next = tasks; next[i].title = clean; next[i].deadline = deadline
        return commit(next)
    }
    func transition(_ id: UUID, to status: TaskStatus, now: Date = Date()) {
        guard let i = tasks.firstIndex(where: { $0.id == id }), tasks[i].status != status else { return }
        var next = tasks
        next[i].status = status; next[i].position = nextPosition(status)
        next[i].completedAt = status == .completed ? now : nil
        next[i].cancelledAt = status == .cancelled ? now : nil
        commit(next)
    }
    @discardableResult func deleteArchived(_ ids: Set<UUID>, from status: TaskStatus) -> Bool {
        guard status != .todo, !ids.isEmpty else { return false }
        let next = tasks.filter { !(ids.contains($0.id) && $0.status == status) }
        guard next.count != tasks.count else { return false }
        return commit(next)
    }
    func move(_ id: UUID, before target: UUID?) { move([id], before: target) }
    func move(_ ids: Set<UUID>, before target: UUID?) {
        let original = items(.todo).map(\.id)
        let moving = original.filter { ids.contains($0) }
        guard !moving.isEmpty, target == nil || (original.contains(target!) && !ids.contains(target!)) else { return }
        var ordered = original.filter { !ids.contains($0) }
        ordered.insert(contentsOf: moving, at: target.flatMap { ordered.firstIndex(of: $0) } ?? ordered.count)
        guard ordered != original else { return }
        var next = tasks
        for (position, id) in ordered.enumerated() { if let i = next.firstIndex(where: { $0.id == id }) { next[i].position = position } }
        commit(next)
    }
    func cancel(_ ids: Set<UUID>, now: Date = Date()) {
        let moving = items(.todo).filter { ids.contains($0.id) }
        guard !moving.isEmpty else { return }
        var next = tasks
        let position = nextPosition(.cancelled)
        for (offset, task) in moving.enumerated() {
            if let i = next.firstIndex(where: { $0.id == task.id }) {
                next[i].status = .cancelled; next[i].position = position + offset
                next[i].completedAt = nil; next[i].cancelledAt = now
            }
        }
        commit(next)
    }

}
enum DeadlineText {
    static let formatter: DateFormatter = {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "MMM d, yyyy '·' h:mm a"; return f
    }()
    static func string(_ date: Date) -> String {
        formatter.locale = Preferences.locale
        formatter.dateFormat = (Preferences.chinese ? "yyyy年M月d日" : "MMM d, yyyy") + (Preferences.hour24 ? " '·' HH:mm" : " '·' h:mm a")
        return formatter.string(from: date)
    }
}
