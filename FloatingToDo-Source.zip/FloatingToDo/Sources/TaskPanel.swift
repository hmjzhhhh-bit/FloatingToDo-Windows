import AppKit
import SwiftUI

struct TaskPanel: View {
    @ObservedObject var store: TaskStore
    let close: () -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage("taskSize") private var taskSize = 14.0
    @AppStorage("textOffset") private var textOffset = 0.0
    @AppStorage("language") private var language = "en"
    @AppStorage("hour24") private var hour24 = false
    @State private var showingSettings = false
    @State private var confirmingQuit = false
    @State private var tab: TaskStatus = .todo
    @State private var confirmingDelete = false
    @State private var pendingIDs: Set<UUID> = []
    @State private var pendingStatus: TaskStatus = .completed
    @State private var title = ""
    @State private var deadline: Date?
    @State private var choosingDate = false
    @State private var editing: TodoTask?
    @State private var dropTarget: UUID?
    @State private var selectedIDs: Set<UUID> = []
    @State private var selectionRect: CGRect?
    @State private var dragging: UUID?
    @State private var dragPoint = CGPoint.zero
    @State private var grabOffset = CGSize.zero
    @State private var trashFrame = CGRect.zero
    @State private var listFrame = CGRect.zero
    private var overTrash: Bool { dragging != nil && tab != .todo && trashFrame.contains(dragPoint) }
    @State private var rowFrames: [UUID: CGRect] = [:]
    @FocusState private var inputFocused: Bool
    private var animation: Animation? { reduceMotion ? nil : .easeInOut(duration: 0.2) }
    var body: some View {
        let _ = (language, hour24, taskSize, textOffset)
        return VStack(spacing: 0) {
            ZStack(alignment: .trailing) {
                WindowDragArea().frame(height: 30).help("Drag to move panel")
                HStack(spacing: 2) {
                Button { showingSettings.toggle() } label: {
                    Image(systemName: "gearshape").font(.system(size: 13, weight: .light)).frame(width: 30, height: 30)
                }.buttonStyle(.plain).accessibilityLabel(L("Settings", "设置"))
                    .popover(isPresented: $showingSettings) { PreferencesView() }
                Button { confirmingQuit = true } label: {
                    Image(systemName: "xmark").font(AppTypography.font(11))
                        .frame(width: 32, height: 30).contentShape(Rectangle())
                }.buttonStyle(.plain).accessibilityLabel(L("Quit Floating To-Do", "退出 Floating To-Do"))
                }.padding(.trailing, 8)
            }
            HStack(spacing: 0) {
                ForEach(TaskStatus.allCases, id: \.self) { item in
                    Button { withAnimation(animation) { tab = item; resetDrag(); selectedIDs = []; selectionRect = nil } } label: {
                        mixedText(item.label, size: 13)
                            .frame(maxWidth: .infinity).frame(height: 46)
                            .foregroundStyle(Color.black)
                            .overlay(alignment: .bottom) {
                                Rectangle().fill(tab == item ? Color(white: 0.32) : .clear).frame(height: 1)
                            }
                            .contentShape(Rectangle())
                    }.buttonStyle(.plain).accessibilityAddTraits(tab == item ? [.isSelected] : [])
                }
            }.padding(.horizontal, 12)
            Divider().opacity(0.4)
            TimelineView(.periodic(from: .now, by: 1)) { context in
                ScrollViewReader { proxy in
                ScrollView {
                    VStack(spacing: 0) {
                        if store.items(tab).isEmpty {
                            Text(tab.empty).font(AppTypography.font(13)).foregroundStyle(.secondary).frame(maxWidth: .infinity).padding(.top, 100)
                        }
                        ForEach(store.items(tab)) { task in
                            TaskRow(task: task, now: context.date, edit: { editing = task }, dragChanged: { updateDrag(task.id, value: $0) }, dragEnded: { finishDrag(task.id) }, action: { status in
                                withAnimation(animation) { store.transition(task.id, to: status) }
                            })
                            .padding(.horizontal, 18)
                            .overlay(alignment: .top) { if tab == .todo && dragging != nil && dropTarget == task.id { Rectangle().fill(Color.gray.opacity(0.6)).frame(height: 2).padding(.horizontal, 22) } }
                            .background(GeometryReader { geometry in
                                Color.clear.preference(key: RowFrames.self, value: [task.id: geometry.frame(in: .named("taskPanel"))])
                            })
                            .background(selectedIDs.contains(task.id) ? Color.black.opacity(0.09) : Color.clear)
                            .accessibilityAddTraits(selectedIDs.contains(task.id) ? [.isSelected] : [])
                            .opacity(dragging != nil && (dragging == task.id || (tab != .todo && selectedIDs.contains(task.id))) ? 0.2 : 1)
                            .id(task.id)
                        }
                        if tab == .todo && dragging != nil && dropTarget == nil {
                            Rectangle().fill(Color.gray.opacity(0.6)).frame(height: 2).padding(.horizontal, 22)
                        }
                        Color.clear.frame(height: 25)
                    }.padding(.vertical, 10)
                        .onPreferenceChange(RowFrames.self) { rowFrames = $0 }
                } .background(ArchiveMarquee(enabled: tab != .todo, blocked: Array(rowFrames.values), origin: listFrame.origin, changed: { start, end in
                    selectionRect = ArchiveSelection.rect(start, end).intersection(listFrame)
                    selectedIDs = ArchiveSelection.ids(in: selectionRect ?? .zero, frames: rowFrames)
                }, ended: { selectionRect = nil }))
                .background(GeometryReader { geometry in
                    Color.clear.preference(key: ListBounds.self, value: geometry.frame(in: .named("taskPanel")))
                })
                .onPreferenceChange(ListBounds.self) { listFrame = $0 }
                .onReceive(Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()) { _ in
                    guard dragging != nil else { return }
                    let items = store.items(tab)
                    let visible = items.filter { rowFrames[$0.id].map { $0.intersects(listFrame) } ?? false }
                    if dragPoint.y < listFrame.minY + 28, let first = visible.first,
                       let i = items.firstIndex(where: { $0.id == first.id }), i > 0 {
                        withAnimation(reduceMotion ? nil : .linear(duration: 0.1)) { proxy.scrollTo(items[i - 1].id, anchor: .top) }
                    } else if dragPoint.y > listFrame.maxY - 28 && dragPoint.y < listFrame.maxY + 8,
                              let last = visible.last, let i = items.firstIndex(where: { $0.id == last.id }), i + 1 < items.count {
                        withAnimation(reduceMotion ? nil : .linear(duration: 0.1)) { proxy.scrollTo(items[i + 1].id, anchor: .bottom) }
                    }
                }
                }
            }
            if tab == .todo { composer } else { archiveFooter }
        }
        .coordinateSpace(name: "taskPanel")
        .overlay(alignment: .topLeading) {
            if let rect = selectionRect {
                Rectangle().fill(Color.black.opacity(0.07)).overlay(Rectangle().stroke(Color.gray, lineWidth: 1))
                    .frame(width: max(0, rect.width), height: max(0, rect.height))
                    .offset(x: rect.minX, y: rect.minY).allowsHitTesting(false)
            }
            if let id = dragging, let task = store.tasks.first(where: { $0.id == id }), let frame = rowFrames[id] {
                VStack(alignment: .leading, spacing: 5) {
                    if tab != .todo && selectedIDs.count > 1 {
                        Text(L("\(selectedIDs.count) selected tasks", "已选 \(selectedIDs.count) 条待办")).font(AppTypography.font(11))
                    }
                    mixedText(task.title, size: taskSize).lineLimit(2)
                    if let deadline = task.deadline { Text(DeadlineText.string(deadline)).font(AppTypography.font(11)).foregroundColor(.secondary) }
                }.padding(10).frame(width: frame.width, alignment: .leading)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 10))
                    .shadow(color: .black.opacity(0.16), radius: 8, y: 3)
                    .offset(x: dragPoint.x - grabOffset.width, y: dragPoint.y - grabOffset.height)
                    .allowsHitTesting(false)
            }
        }
        .buttonStyle(QuietButton()).foregroundStyle(Color(white: 0.22))
        .font(AppTypography.font(13)).preferredColorScheme(.light)
        .sheet(item: $editing) { task in
            EditTask(task: task, store: store) { editing = nil }
        }
        .alert("Storage Error", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
            Button(L("OK", "好")) { store.error = nil }
        } message: { Text(store.error ?? "") }
        .alert(L("Permanently delete \(pendingIDs.count) tasks?", "永久删除 \(pendingIDs.count) 条待办？"), isPresented: $confirmingDelete) {
            Button(L("Cancel", "取消"), role: .cancel) { pendingIDs = [] }
            Button(L("Delete", "删除"), role: .destructive) {
                withAnimation(animation) {
                    _ = store.deleteArchived(pendingIDs, from: pendingStatus)
                    pendingIDs = []
                }
            }
        } message: { Text(L("This cannot be undone.", "此操作无法撤销。")) }
        .alert(L("Quit Floating To-Do?", "退出 Floating To-Do？"), isPresented: $confirmingQuit) {
            Button(L("Cancel", "取消"), role: .cancel) { }
            Button(L("Quit", "退出"), role: .destructive) { NSApp.terminate(nil) }
        } message: { Text(L("Your saved tasks will be here when you reopen the app.", "已保存的待办会保留，下次打开仍可查看。")) }
        .onChange(of: store.tasks) { tasks in selectedIDs.formIntersection(Set(tasks.filter { $0.status == tab }.map(\.id))); if let id = dragging, !tasks.contains(where: { $0.id == id && $0.status == tab }) { resetDrag() } }
        .onExitCommand {
            if dragging != nil { resetDrag() }
            else if !selectedIDs.isEmpty { selectedIDs = []; selectionRect = nil }
            else if choosingDate { choosingDate = false }
            else if !DeadlinePopoverState.blocksParentEscape {
                if editing != nil { editing = nil } else { close() }
            }
        }
    }
    private var archiveFooter: some View {
        VStack(spacing: 6) {
            Divider().opacity(0.4)
            HStack {
                Text(selectedIDs.isEmpty ? L("Drag blank space to select tasks", "拖动空白处框选待办") : L("Drag \(selectedIDs.count) selected here", "将选中的 \(selectedIDs.count) 条拖到这里"))
                    .font(AppTypography.font(11)).foregroundColor(.secondary)
                Spacer()
                Image(systemName: "trash").font(.system(size: 17, weight: .light))
                    .frame(width: 54, height: 48)
                    .background(Color.black.opacity(overTrash ? 0.22 : 0.025), in: RoundedRectangle(cornerRadius: 14))
                    .scaleEffect(overTrash ? 1.22 : 1)
                    .animation(reduceMotion ? nil : .easeOut(duration: 0.13), value: overTrash)
                    .background(GeometryReader { geometry in
                        Color.clear.preference(key: TrashBounds.self, value: geometry.frame(in: .named("taskPanel")))
                    })
                    .accessibilityLabel(L("Drop here to delete", "拖到这里删除"))
            }
        }.padding(.horizontal, 18).padding(.bottom, 10)
            .onPreferenceChange(TrashBounds.self) { trashFrame = $0 }
    }
    private var composer: some View {
        VStack(spacing: 8) {
            Divider().opacity(0.5)
            if let deadline {
                Text(DeadlineText.string(deadline)).font(AppTypography.font(11)).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 22)
            }
            HStack(spacing: 6) {
                TextField(L("Add new to-do...", "添加待办…"), text: $title).textFieldStyle(.plain).font(AppTypography.font(13))
                    .focused($inputFocused).onSubmit(add)
                Button { choosingDate = true } label: { Image(systemName: deadline == nil ? "calendar" : "calendar.badge.clock") }
                    .accessibilityLabel("Choose deadline")
                    .popover(isPresented: $choosingDate, arrowEdge: .top) {
                        DeadlinePicker(date: deadline, save: { deadline = $0; choosingDate = false }, cancel: { choosingDate = false })
                    }
                Button(action: add) { Image(systemName: "plus").font(AppTypography.font(16)) }
                    .disabled(title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty).accessibilityLabel("Add to-do")
            }.padding(.horizontal, 18).padding(.bottom, 16).padding(.top, 3)
        }
    }
    private func add() {
        withAnimation(animation) {
            if store.add(title, deadline: deadline) { title = ""; deadline = nil; inputFocused = true }
        }
    }

    private func updateDrag(_ id: UUID, value: DragGesture.Value) {
        guard let frame = rowFrames[id] else { return }
        if dragging == nil { if tab != .todo && !selectedIDs.contains(id) { selectedIDs = [id] }; grabOffset = CGSize(width: value.startLocation.x - frame.minX, height: value.startLocation.y - frame.minY) }
        dragging = id; dragPoint = value.location
        if tab == .todo { dropTarget = DragPlacement.target(id: id, y: dragPoint.y, ordered: store.items(.todo).map(\.id), frames: rowFrames) }
    }
    private func resetDrag() { dragging = nil; dropTarget = nil }
    private func finishDrag(_ id: UUID) {
        guard dragging == id else { return }
        if tab == .todo {
            let target = DragPlacement.target(id: id, y: dragPoint.y, ordered: store.items(.todo).map(\.id), frames: rowFrames)
            withAnimation(animation) { store.move(id, before: target) }
        } else if overTrash {
            pendingIDs = selectedIDs.isEmpty ? [id] : selectedIDs; pendingStatus = tab; confirmingDelete = true
        }
        resetDrag()
    }

}
enum ArchiveSelection {
    static func rect(_ a: CGPoint, _ b: CGPoint) -> CGRect {
        CGRect(x: min(a.x,b.x), y: min(a.y,b.y), width: abs(a.x-b.x), height: abs(a.y-b.y))
    }
    static func ids(in rect: CGRect, frames: [UUID: CGRect]) -> Set<UUID> {
        guard !rect.isNull, rect.width > 1, rect.height > 1 else { return [] }
        return Set(frames.filter { $0.value.intersects(rect) }.map(\.key))
    }
}
enum DragPlacement {
    static func target(id: UUID, y: CGFloat, ordered: [UUID], frames: [UUID: CGRect]) -> UUID? {
        ordered.first { $0 != id && frames[$0].map { y < $0.midY } == true }
    }
}
private struct TrashBounds: PreferenceKey {
    static var defaultValue = CGRect.zero
    static func reduce(value: inout CGRect, nextValue: () -> CGRect) { let next = nextValue(); if !next.isEmpty { value = next } }
}
private struct ListBounds: PreferenceKey {
    static var defaultValue = CGRect.zero
    static func reduce(value: inout CGRect, nextValue: () -> CGRect) { let next = nextValue(); if !next.isEmpty { value = next } }
}
private struct RowFrames: PreferenceKey {
    static var defaultValue: [UUID: CGRect] = [:]
    static func reduce(value: inout [UUID: CGRect], nextValue: () -> [UUID: CGRect]) { value.merge(nextValue(), uniquingKeysWith: { _, new in new }) }

}
struct TaskRow: View {
    @AppStorage("taskSize") private var taskSize = 14.0
    @AppStorage("textOffset") private var textOffset = 0.0
    @AppStorage("language") private var language = "en"
    @AppStorage("hour24") private var hour24 = false
    let task: TodoTask
    let now: Date
    let edit: () -> Void
    let dragChanged: (DragGesture.Value) -> Void
    let dragEnded: () -> Void
    let action: (TaskStatus) -> Void
    @State private var hovering = false
    @FocusState private var titleFocused: Bool
    private var muted: Bool { task.isOverdue(at: now) }
    var body: some View {
        let _ = (language, hour24)
        return HStack(alignment: .firstTextBaseline, spacing: 10) {
            Button { if task.status == .todo { action(.completed) } } label: {
                Image(systemName: task.status == .todo ? "square" : task.status == .completed ? "checkmark.square" : "minus.square")
                    .font(.system(size: 16, weight: .light)).frame(width: 18, height: 20).alignmentGuide(.firstTextBaseline) { $0[.bottom] - 4 }
            }.disabled(task.status != .todo).accessibilityLabel(task.status == .todo ? "Complete \(task.title)" : task.status.label)
            Button(action: edit) {
                VStack(alignment: .leading, spacing: 5) {
                    mixedText(task.title, size: taskSize).lineLimit(2).multilineTextAlignment(.leading)
                    if let date = task.deadline { Text(DeadlineText.string(date)).font(AppTypography.font(11)).opacity(muted ? 1 : 0.6) }
                }.frame(maxWidth: .infinity, alignment: .leading).offset(y: textOffset).contentShape(Rectangle())

            }.buttonStyle(.plain)
                .help("Click to edit; drag to reorder")
                .contentShape(Rectangle())
                .highPriorityGesture(DragGesture(minimumDistance: 4, coordinateSpace: .named("taskPanel")).onChanged(dragChanged).onEnded { _ in dragEnded() })
                .accessibilityElement(children: .combine)
                .accessibilityAddTraits(.isButton)
                .accessibilityAction { edit() }
                .focused($titleFocused)
                .overlay(RoundedRectangle(cornerRadius: 4).stroke(titleFocused ? Color.gray.opacity(0.4) : .clear, lineWidth: 1))
            Button { action(task.status == .todo ? .cancelled : .todo) } label: {
                Image(systemName: task.status == .todo ? "trash" : "arrow.uturn.backward").font(AppTypography.font(13)).frame(height: 20)
            }.accessibilityLabel("\(task.status == .todo ? "Cancel" : "Restore") \(task.title)")
        }.foregroundStyle(muted ? Color.gray.opacity(0.75) : Color(white: 0.22))
            .padding(.vertical, 8)
            .background(Color.black.opacity(hovering ? 0.025 : 0), in: RoundedRectangle(cornerRadius: 8))
            .onHover { hovering = $0 }
            .contextMenu {
                Button(L("Edit", "编辑"), action: edit)
                if task.status == .todo { Button(L("Complete", "完成")) { action(.completed) }; Button(L("Cancel To-Do", "取消待办")) { action(.cancelled) } }
                else { Button(L("Restore", "恢复")) { action(.todo) } }
            }
    }
}
struct EditTask: View {
    let task: TodoTask
    @ObservedObject var store: TaskStore
    let dismiss: () -> Void
    @State private var title: String
    @State private var deadline: Date?
    @State private var choosingDate = false
    init(task: TodoTask, store: TaskStore, dismiss: @escaping () -> Void) {
        self.task = task; self.store = store; self.dismiss = dismiss
        _title = State(initialValue: task.title); _deadline = State(initialValue: task.deadline)
    }
    @ViewBuilder private var titleEditor: some View {
        if #available(macOS 13, *) {
            TextField(L("Task title", "待办内容"), text: $title, axis: .vertical).lineLimit(2...4).textFieldStyle(.plain)
        } else {
            TextEditor(text: $title).frame(height: 64).accessibilityLabel("Task title")
        }
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(L("Edit To-Do", "编辑待办")).font(AppTypography.font(14))
            titleEditor.padding(8).background(Color.black.opacity(0.04), in: RoundedRectangle(cornerRadius: 6))
            Button { choosingDate = true } label: { Label(deadline.map(DeadlineText.string) ?? L("Choose deadline", "选择截止时间"), systemImage: "calendar") }
                .popover(isPresented: $choosingDate) {
                    DeadlinePicker(date: deadline, save: { deadline = $0; choosingDate = false }, cancel: { choosingDate = false })
                }
            if let error = store.error { Text(error).font(AppTypography.font(11)).foregroundStyle(.secondary) }
            HStack {
                Spacer(); Button(L("Cancel", "取消"), action: dismiss).keyboardShortcut(.cancelAction)
                Button(L("Save", "保存")) { if store.edit(task.id, title: title, deadline: deadline) { dismiss() } }
                    .keyboardShortcut(.defaultAction).disabled(title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }.padding(24).frame(width: 320).buttonStyle(QuietButton()).tint(.black).font(AppTypography.font(13)).preferredColorScheme(.light)
            .onExitCommand { if choosingDate { choosingDate = false } else if !DeadlinePopoverState.blocksParentEscape { dismiss() } }
    }
}

// Observe only this list's blank-area drags; leave task buttons and scrolling native.
struct ArchiveMarquee: NSViewRepresentable {
    var enabled: Bool
    var blocked: [CGRect]
    var origin: CGPoint
    var changed: (CGPoint, CGPoint) -> Void
    var ended: () -> Void
    func makeNSView(context: Context) -> MonitorView { MonitorView() }
    func updateNSView(_ view: MonitorView, context: Context) { view.config = self }
    final class MonitorView: NSView {
        var config: ArchiveMarquee?
        var monitor: Any?
        var start: CGPoint?
        override var isFlipped: Bool { true }
        override func hitTest(_ point: NSPoint) -> NSView? { nil }
        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            if let monitor { NSEvent.removeMonitor(monitor); self.monitor = nil }
            guard window != nil else { return }
            monitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .leftMouseDragged, .leftMouseUp]) { [weak self] event in
                guard let self, let config = self.config else { return event }
                guard config.enabled, event.window === self.window else { return event }
                let local = self.convert(event.locationInWindow, from: nil)
                let point = CGPoint(x: local.x + config.origin.x, y: local.y + config.origin.y)
                if event.type == .leftMouseDown {
                    self.start = self.bounds.contains(local) && !config.blocked.contains(where: { $0.contains(point) }) ? point : nil
                }
                if let start = self.start {
                    config.changed(start, point)
                    if event.type == .leftMouseUp { self.start = nil; config.ended() }
                }
                return event
            }
        }
        deinit { if let monitor { NSEvent.removeMonitor(monitor) } }
    }
}
