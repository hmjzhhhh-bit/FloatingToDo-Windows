import SwiftUI

// SwiftUI can forward the same Escape through a dismissed popover to its parent.
enum DeadlinePopoverState {
    static var isVisible = false
    static var lastClosed = Date.distantPast
    static var blocksParentEscape: Bool { isVisible || Date().timeIntervalSince(lastClosed) < 0.25 }
}

struct DeadlinePicker: View {
    let save: (Date?) -> Void
    let cancel: () -> Void
    @State private var day: Date
    @State private var month: Date
    @State private var hour: Int
    @State private var minute: Int
    @State private var period: Int
    private var calendar: Calendar { var c = Calendar(identifier: .gregorian); c.locale = Preferences.locale; return c }
    init(date: Date?, save: @escaping (Date?) -> Void, cancel: @escaping () -> Void) {
        self.save = save; self.cancel = cancel
        let date = date ?? Date(); let c = Calendar(identifier: .gregorian)
        _day = State(initialValue: date); _month = State(initialValue: c.date(from: c.dateComponents([.year, .month], from: date))!)
        let h = c.component(.hour, from: date)
        _hour = State(initialValue: Preferences.hour24 ? h : (h + 11) % 12); _minute = State(initialValue: c.component(.minute, from: date)); _period = State(initialValue: h >= 12 ? 1 : 0)
    }
    var body: some View {
        VStack(spacing: 12) {
            HStack {
                Button { changeMonth(-1) } label: { Image(systemName: "chevron.left") }.accessibilityLabel("Previous month")
                Spacer()
                Text(month.formatted(.dateTime.month(.wide).year().locale(Preferences.locale))).font(AppTypography.font(14))
                Spacer()
                Button { changeMonth(1) } label: { Image(systemName: "chevron.right") }.accessibilityLabel("Next month")
            }
            calendarGrid
            Divider()
            HStack(spacing: 12) {
                wheel(L("Hour", "时"), values: (Preferences.hour24 ? Array(0...23) : Array(1...12)).map { String(format: "%02d", $0) }, selection: $hour)
                wheel(L("Minute", "分"), values: (0...59).map { String(format: "%02d", $0) }, selection: $minute)
                if !Preferences.hour24 { wheel("AM/PM", values: ["AM", "PM"], selection: $period) }
            }
            HStack {
                Button(L("Clear Deadline", "清除时间")) { save(nil) }.font(AppTypography.font(11))
                Spacer()
                Button(L("Cancel", "取消"), action: cancel).keyboardShortcut(.cancelAction)
                Button(L("Save", "保存")) { save(selectedDate) }.keyboardShortcut(.defaultAction)
            }.font(AppTypography.font(12))
        }
        .buttonStyle(QuietButton()).padding(16).frame(width: 286)
        .foregroundStyle(Color(white: 0.22)).font(AppTypography.font(13)).preferredColorScheme(.light)
        .onAppear { DeadlinePopoverState.isVisible = true }
        .onDisappear { DeadlinePopoverState.isVisible = false; DeadlinePopoverState.lastClosed = Date() }
        .onExitCommand(perform: cancel)
    }
    private var calendarGrid: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 2), count: 7), spacing: 3) {
            ForEach(Array((Preferences.chinese ? ["日", "一", "二", "三", "四", "五", "六"] : ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]).enumerated()), id: \.offset) { _, name in
                Text(name).font(AppTypography.font(10)).foregroundStyle(.secondary)
            }
            ForEach(0..<42, id: \.self) { index in calendarCell(index) }
        }
    }
    @ViewBuilder private func calendarCell(_ index: Int) -> some View {
        let number = index - (calendar.component(.weekday, from: month) - 1) + 1
        if let range = calendar.range(of: .day, in: .month, for: month), range.contains(number), let date = calendar.date(byAdding: .day, value: number - 1, to: month) {
            let chosen = calendar.isDate(date, inSameDayAs: day)
            Button { day = date } label: {
                Text("\(number)")
                    .font(AppTypography.font(12))
                    .frame(width: 28, height: 26)
                    .foregroundStyle(chosen ? Color.white : Color.black)
                    .background(chosen ? Color.black.opacity(0.85) : Color.clear, in: RoundedRectangle(cornerRadius: 6))
                    .overlay(RoundedRectangle(cornerRadius: 6).stroke(calendar.isDateInToday(date) ? Color.gray.opacity(0.5) : .clear, lineWidth: 1))
            }.buttonStyle(.plain)
                .accessibilityLabel(date.formatted(.dateTime.month().day().year().locale(Preferences.locale)))
                .accessibilityAddTraits(chosen ? [.isSelected] : [])
        } else { Color.clear.frame(width: 28, height: 26) }
    }
    private func wheel(_ label: String, values: [String], selection: Binding<Int>) -> some View {
        VStack(spacing: 2) {
            Text(label).font(AppTypography.font(10)).foregroundStyle(.secondary)
            TimeWheel(values: values, selection: selection, label: label, cancel: cancel).frame(height: 126)
        }
    }
    private var selectedDate: Date {
        let h = Preferences.hour24 ? hour : (hour + 1) % 12 + period * 12
        // Calendar resolves nonexistent daylight-saving times to the next valid time on the selected day.
        return calendar.date(bySettingHour: h, minute: minute, second: 0, of: day) ?? day
    }
    private func changeMonth(_ offset: Int) { month = calendar.date(byAdding: .month, value: offset, to: month)! }
}
