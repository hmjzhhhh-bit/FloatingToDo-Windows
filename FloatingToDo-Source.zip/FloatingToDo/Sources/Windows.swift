import AppKit
import SwiftUI

 enum WindowGeometry {
    static func clamp(_ frame: NSRect, to visible: NSRect) -> NSRect {
        var result = frame
        result.size.width = min(frame.width, visible.width)
        result.size.height = min(frame.height, visible.height)
        result.origin.x = min(max(frame.minX, visible.minX), visible.maxX - result.width)
        result.origin.y = min(max(frame.minY, visible.minY), visible.maxY - result.height)
        return result
    }
    static func expanded(from circle: NSRect, within visible: NSRect) -> NSRect {
        let size = NSSize(width: min(400, visible.width), height: min(460, visible.height))
        let x = circle.midX > visible.midX ? circle.maxX - size.width : circle.minX
        let y = circle.midY > visible.midY ? circle.maxY - size.height : circle.minY
        return clamp(NSRect(origin: NSPoint(x: x, y: y), size: size), to: visible)
    }
    static func interpolate(_ a: NSRect, _ b: NSRect, _ fraction: CGFloat) -> NSRect {
        NSRect(x: a.minX + (b.minX - a.minX) * fraction, y: a.minY + (b.minY - a.minY) * fraction,
               width: a.width + (b.width - a.width) * fraction, height: a.height + (b.height - a.height) * fraction)
    }
}
struct MorphGeometry {
    let frame: NSRect
    let radius: CGFloat
    let counterOpacity: CGFloat
    let contentOpacity: CGFloat
    static func smooth(_ value: CGFloat) -> CGFloat {
        let t = min(1, max(0, value)); return t * t * (3 - 2 * t)
    }
    static func sample(progress: CGFloat, circle: NSRect, expanded: NSRect) -> Self {
        // A shared path makes collapse the exact reverse, including mid-animation reversals.
        let square = smooth(progress / (50.0 / 240.0))
        let growth = smooth((progress - 50.0 / 240.0) / (190.0 / 240.0))
        return Self(frame: WindowGeometry.interpolate(circle, expanded, growth),
                    radius: progress < 50.0 / 240.0 ? 32 - 16 * square : 16 + 4 * growth,
                    counterOpacity: 1 - square,
                    contentOpacity: smooth((progress - 0.68) / 0.32))
    }
}
final class FloatingPanel: NSPanel {
    var dismissPanel: (() -> Void)?
    override func cancelOperation(_ sender: Any?) { if !DeadlinePopoverState.blocksParentEscape { dismissPanel?() } }
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }
}

@MainActor final class WindowController: NSObject, NSWindowDelegate {
    let store: TaskStore
    let window: FloatingPanel
    private(set) var collapsedFrame = NSRect(x: 0, y: 0, width: 64, height: 64)
    private(set) var expandedFrame = NSRect.zero
    private(set) var progress: CGFloat = 0
    private(set) var wantsExpanded = false
    var isAnimating: Bool { timer != nil }
    private var surface: MorphSurface!
    private var timer: Timer?
    private var lastTick: TimeInterval = 0
    private var applyingFrame = false
    private var previousOrigin = NSPoint.zero
    private var observer: NSObjectProtocol?
    private var outsideMonitor: Any?
    private var localMonitor: Any?
    private var quickPanels: [FloatingPanel] = []
    private var quickTimer: Timer?
    private var quickInput: FloatingPanel?

    init(store: TaskStore) {
        self.store = store
        window = FloatingPanel(contentRect: collapsedFrame, styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        super.init()
        window.title = "Floating To-Do"; window.isOpaque = false; window.backgroundColor = .clear
        window.hasShadow = true; window.level = .floating; window.hidesOnDeactivate = false
        window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
        window.isReleasedWhenClosed = false; window.isMovableByWindowBackground = false
        window.appearance = NSAppearance(named: .aqua)
        surface = MorphSurface(store: store, open: { [weak self] in self?.openPanel() }, close: { [weak self] in self?.closePanel() }, contextAction: { [weak self] in self?.showQuickActions() })
        window.contentView = surface
        window.delegate = self
        window.dismissPanel = { [weak self] in self?.closePanel() }
        if let xy = UserDefaults.standard.array(forKey: "widgetPosition") as? [Double], xy.count == 2, xy.allSatisfy({ $0.isFinite }) {
            collapsedFrame.origin = NSPoint(x: xy[0], y: xy[1])
            recoverWindows()
        } else { resetPosition() }
        outsideMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown, .otherMouseDown]) { [weak self] _ in
            MainActor.assumeIsolated { self?.handleOutsideMouse() }
        }
        localMonitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .rightMouseDown, .otherMouseDown]) { [weak self] event in
            MainActor.assumeIsolated {
                if event.window == nil { self?.handleOutsideMouse() }
            }
            return event
        }
        observer = NotificationCenter.default.addObserver(forName: NSApplication.didChangeScreenParametersNotification, object: nil, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.recoverWindows() }
        }
    }
    deinit { timer?.invalidate(); quickTimer?.invalidate(); if let outsideMonitor { NSEvent.removeMonitor(outsideMonitor) }; if let localMonitor { NSEvent.removeMonitor(localMonitor) }; if let observer { NotificationCenter.default.removeObserver(observer) } }
    private func usableScreen(for frame: NSRect) -> NSRect? {
        guard let first = NSScreen.screens.first else { return nil }
        let screen = NSScreen.screens.max { $0.visibleFrame.intersection(frame).area < $1.visibleFrame.intersection(frame).area } ?? first
        return (screen.visibleFrame.intersects(frame) ? screen : first).visibleFrame.insetBy(dx: 8, dy: 8)
    }
    func showWidget() {
        recoverWindows(); setExpanded(false); window.orderFrontRegardless()
    }
    func resetPosition() {
        guard let screen = NSScreen.screens.first else { return }
        stopAnimation(); wantsExpanded = false; progress = 0
        collapsedFrame = NSRect(x: screen.visibleFrame.maxX - 96, y: screen.visibleFrame.maxY - 112, width: 64, height: 64)
        recoverWindows()
    }
    func recoverWindows() {
        guard let visible = usableScreen(for: collapsedFrame) else { return }
        stopAnimation()
        collapsedFrame = WindowGeometry.clamp(collapsedFrame, to: visible)
        expandedFrame = WindowGeometry.expanded(from: collapsedFrame, within: visible)
        progress = wantsExpanded ? 1 : 0
        render(); savePosition()
    }
    func openPanel() { hideQuickActions(); setExpanded(true); window.makeKeyAndOrderFront(nil) }
    func closePanel() { hideQuickActions(); setExpanded(false) }
    private func handleOutsideMouse() {
        let point = NSEvent.mouseLocation
        guard !NSApp.windows.contains(where: { $0.isVisible && $0.frame.contains(point) }) else { return }
        dismissOutside()
    }
    func dismissOutside() {
        // Popovers and sheets are app windows; their clicks never reach the global monitor.
        guard window.attachedSheet == nil else { return }
        closePanel()
    }
    func hideQuickActions() {
        quickTimer?.invalidate(); quickTimer = nil
        quickPanels.forEach { $0.orderOut(nil) }; quickPanels = []
        quickInput?.orderOut(nil); quickInput = nil
    }
    func showQuickActions() {
        guard progress == 0 else { return }
        if !quickPanels.isEmpty || quickInput != nil { hideQuickActions(); return }
        guard let visible = usableScreen(for: collapsedFrame) else { return }
        let side: CGFloat = collapsedFrame.midX + 110 < visible.maxX ? 1 : -1
        let center = NSPoint(x: collapsedFrame.midX, y: collapsedFrame.midY)
        let targets = [CGFloat(1), CGFloat(-1)].map { direction in
            WindowGeometry.clamp(NSRect(x: center.x + side * 70 - 24, y: center.y + direction * 46 - 24, width: 48, height: 48), to: visible)
        }
        for index in 0..<2 {
            let panel = FloatingPanel(contentRect: NSRect(x: center.x - 24, y: center.y - 24, width: 48, height: 48), styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
            panel.isReleasedWhenClosed = false; panel.isOpaque = false; panel.backgroundColor = .clear
            panel.level = .floating; panel.hasShadow = true; panel.hidesOnDeactivate = false
            panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
            panel.contentView = NSHostingView(rootView: QuickActionButton(symbol: index == 0 ? "power" : "plus", title: index == 0 ? L("Quit", "退出") : L("Add new to-do", "添加待办")) { [weak self] in
                if index == 0 { NSApp.terminate(nil) } else { self?.showQuickInput() }
            })
            panel.dismissPanel = { [weak self] in self?.hideQuickActions() }
            quickPanels.append(panel); panel.orderFrontRegardless()
        }
        let began = ProcessInfo.processInfo.systemUptime
        let duration = NSWorkspace.shared.accessibilityDisplayShouldReduceMotion ? 0.001 : 0.24
        quickTimer = Timer.scheduledTimer(withTimeInterval: 1.0 / 60, repeats: true) { [weak self] timer in
            MainActor.assumeIsolated {
                guard let self else { timer.invalidate(); return }
                let t = min(1, (ProcessInfo.processInfo.systemUptime - began) / duration)
                let eased = MorphGeometry.smooth(t)
                for (index, panel) in self.quickPanels.enumerated() {
                    let start = NSRect(x: center.x - 24, y: center.y - 24, width: 48, height: 48)
                    var frame = WindowGeometry.interpolate(start, targets[index], eased)
                    frame.origin.y += sin(t * .pi) * 16
                    panel.setFrame(frame, display: true); panel.alphaValue = eased
                }
                if t == 1 { timer.invalidate(); self.quickTimer = nil }
            }
        }
    }
    func showQuickInput() {
        hideQuickActions()
        guard let visible = usableScreen(for: collapsedFrame) else { return }
        let frame = WindowGeometry.clamp(NSRect(x: collapsedFrame.minX, y: collapsedFrame.minY - 164, width: 340, height: 154), to: visible)
        let panel = FloatingPanel(contentRect: frame, styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        panel.isReleasedWhenClosed = false; panel.isOpaque = false; panel.backgroundColor = .clear
        panel.level = .floating; panel.hasShadow = true; panel.hidesOnDeactivate = false
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
        panel.contentView = NSHostingView(rootView: QuickInput(store: store) { [weak self] in self?.hideQuickActions() })
        panel.dismissPanel = { [weak self] in self?.hideQuickActions() }
        quickInput = panel; panel.makeKeyAndOrderFront(nil)
    }
    func togglePanel() { setExpanded(!wantsExpanded) }
    func setExpanded(_ expanded: Bool, animated: Bool = true) {
        guard expanded != wantsExpanded || (expanded ? progress != 1 : progress != 0) else { return }
        if progress == 0, expanded, let visible = usableScreen(for: collapsedFrame) {
            collapsedFrame = WindowGeometry.clamp(collapsedFrame, to: visible)
            expandedFrame = WindowGeometry.expanded(from: collapsedFrame, within: visible)
        }
        wantsExpanded = expanded
        window.makeFirstResponder(nil)
        if !animated || NSWorkspace.shared.accessibilityDisplayShouldReduceMotion {
            stopAnimation(); progress = expanded ? 1 : 0; render(); return
        }
        // One timer drives native bounds, the glass mask, border and content together.
        guard timer == nil else { return }
        lastTick = ProcessInfo.processInfo.systemUptime
        let timer = Timer(timeInterval: 1.0 / 120.0, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.tick() }
        }
        self.timer = timer
        RunLoop.main.add(timer, forMode: .common)
    }
    private func tick() {
        let now = ProcessInfo.processInfo.systemUptime
        let delta = CGFloat((now - lastTick) / 0.24); lastTick = now
        progress = min(1, max(0, progress + (wantsExpanded ? delta : -delta)))
        render()
        if progress == 0 || progress == 1 { stopAnimation() }
    }
    private func stopAnimation() { timer?.invalidate(); timer = nil }
    private func render() {
        let geometry = MorphGeometry.sample(progress: progress, circle: collapsedFrame, expanded: expandedFrame)
        applyingFrame = true
        window.setFrame(geometry.frame, display: false)
        previousOrigin = window.frame.origin
        surface.update(geometry: geometry, expandedSize: expandedFrame.size, progress: progress)
        window.displayIfNeeded()
        window.invalidateShadow()
        applyingFrame = false
    }
    func savePosition() { UserDefaults.standard.set([collapsedFrame.minX, collapsedFrame.minY], forKey: "widgetPosition") }
    func windowDidMove(_ notification: Notification) {
        guard !applyingFrame else { return }
        let origin = window.frame.origin
        if progress == 0 { collapsedFrame.origin = origin }
        else if progress == 1 {
            collapsedFrame.origin.x += origin.x - previousOrigin.x
            collapsedFrame.origin.y += origin.y - previousOrigin.y
            expandedFrame = window.frame
        }
        previousOrigin = origin
        savePosition()
    }
}
private extension NSRect { var area: CGFloat { isNull ? 0 : width * height } }

/// A single glass surface and two retained content views inside the same native window.
@MainActor final class MorphSurface: NSView {
    private let glass = NSVisualEffectView()
    private let maskShape = CAShapeLayer()
    private let border = CAShapeLayer()
    private let counter: NSHostingView<CounterView>
    private let tasks: NSHostingView<TaskPanel>
    private var progress: CGFloat = 0
    private var radius: CGFloat = 32
    private var accessibilityObserver: NSObjectProtocol?
    init(store: TaskStore, open: @escaping () -> Void, close: @escaping () -> Void, contextAction: @escaping () -> Void) {
        counter = NSHostingView(rootView: CounterView(store: store, open: open, contextAction: contextAction))
        tasks = NSHostingView(rootView: TaskPanel(store: store, close: close))
        super.init(frame: NSRect(x: 0, y: 0, width: 64, height: 64))
        wantsLayer = true; layer?.mask = maskShape
        glass.blendingMode = .behindWindow; glass.material = .hudWindow; glass.state = .active
        glass.appearance = NSAppearance(named: .aqua); glass.wantsLayer = true
        if #available(macOS 13, *) { counter.sizingOptions = []; tasks.sizingOptions = [] }
        addSubview(glass); addSubview(tasks); addSubview(counter)
        border.fillColor = nil; border.strokeColor = NSColor.white.withAlphaComponent(0.65).cgColor; border.lineWidth = 1
        layer?.addSublayer(border)
        updateAccessibility()
        accessibilityObserver = NSWorkspace.shared.notificationCenter.addObserver(forName: NSWorkspace.accessibilityDisplayOptionsDidChangeNotification, object: nil, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.updateAccessibility() }
        }
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    deinit { if let accessibilityObserver { NSWorkspace.shared.notificationCenter.removeObserver(accessibilityObserver) } }
    private func updateAccessibility() {
        glass.layer?.backgroundColor = NSColor.white.withAlphaComponent(NSWorkspace.shared.accessibilityDisplayShouldReduceTransparency ? 1 : 0.10).cgColor
    }
    func update(geometry: MorphGeometry, expandedSize: NSSize, progress: CGFloat) {
        self.progress = progress; radius = geometry.radius
        CATransaction.begin(); CATransaction.setDisableActions(true)
        glass.frame = bounds
        // The task layout never squeezes through a 64 pt square; it is revealed only near the end.
        tasks.frame = NSRect(x: 0, y: bounds.height - expandedSize.height, width: expandedSize.width, height: expandedSize.height)
        counter.frame = NSRect(x: (bounds.width - 64) / 2, y: (bounds.height - 64) / 2, width: 64, height: 64)
        tasks.alphaValue = geometry.contentOpacity; counter.alphaValue = geometry.counterOpacity
        tasks.isHidden = geometry.contentOpacity == 0; counter.isHidden = geometry.counterOpacity == 0
        maskShape.frame = bounds; border.frame = bounds
        // At rest use an actual ellipse path in a strictly square native frame.
        maskShape.path = progress == 0 ? CGPath(ellipseIn: bounds, transform: nil) : CGPath(roundedRect: bounds, cornerWidth: radius, cornerHeight: radius, transform: nil)
        let edge = bounds.insetBy(dx: 0.5, dy: 0.5)
        border.path = progress == 0 ? CGPath(ellipseIn: edge, transform: nil) : CGPath(roundedRect: edge, cornerWidth: max(0, radius - 0.5), cornerHeight: max(0, radius - 0.5), transform: nil)
        CATransaction.commit()
    }
    override func hitTest(_ point: NSPoint) -> NSView? {
        let local = convert(point, from: superview)
        if progress == 0 {
            guard hypot(local.x - bounds.midX, local.y - bounds.midY) <= 32 else { return nil }
        } else if progress != 1 { return self }
        return super.hitTest(point)
    }
}
struct CounterView: View {
    @ObservedObject var store: TaskStore
    let open: () -> Void
    let contextAction: () -> Void
    var body: some View {
        Text("\(store.count)").font(AppTypography.font(26)).foregroundStyle(Color(white: 0.22))
            .lineLimit(1).minimumScaleFactor(0.4).frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(6).frame(width: 64, height: 64).clipShape(Circle())
            .overlay(WidgetInteraction(open: open, contextAction: contextAction))
            .accessibilityElement(children: .ignore).accessibilityLabel("\(store.count) unfinished tasks")
            .accessibilityAddTraits(.isButton).accessibilityAction { open() }
    }
}
struct WidgetInteraction: NSViewRepresentable {
    let open: () -> Void
    let contextAction: () -> Void
    func makeNSView(context: Context) -> InteractionView { let v = InteractionView(); v.open = open; v.contextAction = contextAction; return v }
    func updateNSView(_ view: InteractionView, context: Context) { view.open = open; view.contextAction = contextAction }
    final class InteractionView: NSView {
        var open: (() -> Void)?
        var contextAction: (() -> Void)?
        private var start: NSPoint = .zero
        private var origin: NSPoint = .zero
        private var dragged = false
        override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }
        override func mouseDown(with event: NSEvent) {
            if event.modifierFlags.contains(.control) { contextAction?(); dragged = true; return }
            start = window?.convertPoint(toScreen: event.locationInWindow) ?? .zero
            origin = window?.frame.origin ?? .zero; dragged = false
        }
        override func rightMouseDown(with event: NSEvent) { contextAction?() }
        override func mouseDragged(with event: NSEvent) {
            let current = window?.convertPoint(toScreen: event.locationInWindow) ?? start
            let dx = current.x - start.x; let dy = current.y - start.y
            if hypot(dx, dy) > 5 { dragged = true }
            if dragged { window?.setFrameOrigin(NSPoint(x: origin.x + dx, y: origin.y + dy)) }
        }
        override func mouseUp(with event: NSEvent) { if !dragged { open?() } }

    }
}


struct QuickActionButton: View {
    let symbol: String
    let title: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol).font(.system(size: 19, weight: .light)).foregroundColor(.black)
                .frame(width: 48, height: 48).background(.regularMaterial, in: Circle())
                .overlay(Circle().stroke(Color.black.opacity(0.15), lineWidth: 1))
        }.buttonStyle(.plain).help(title).accessibilityLabel(title).preferredColorScheme(.light)
    }
}
struct QuickInput: View {
    @ObservedObject var store: TaskStore
    let dismiss: () -> Void
    @State private var title = ""
    @State private var deadline: Date?
    @State private var choosingDate = false
    @FocusState private var focused: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(L("Add new to-do", "快速添加待办")).font(AppTypography.font(12))
            HStack {
                TextField(L("What needs doing?", "想做些什么？"), text: $title).textFieldStyle(.plain)
                    .font(AppTypography.font(Preferences.taskSize)).focused($focused).onSubmit(add)
                Button { choosingDate = true } label: {
                    Image(systemName: deadline == nil ? "calendar" : "calendar.badge.clock")
                }.accessibilityLabel(L("Choose deadline", "选择截止时间"))
                    .popover(isPresented: $choosingDate) {
                        DeadlinePicker(date: deadline, save: { deadline = $0; choosingDate = false }, cancel: { choosingDate = false })
                    }
                Button(action: add) { Image(systemName: "plus") }.disabled(title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            if let deadline { Text(DeadlineText.string(deadline)).font(AppTypography.font(11)).foregroundColor(.secondary) }
            if let error = store.error { Text(error).font(.system(size: 10)).foregroundColor(.red) }
        }.padding(18).frame(width: 340, height: 154).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
            .preferredColorScheme(.light).onAppear { focused = true }.onExitCommand { if choosingDate { choosingDate = false } else if !DeadlinePopoverState.blocksParentEscape { dismiss() } }
    }
    private func add() { if store.add(title, deadline: deadline) { dismiss() } }
}
