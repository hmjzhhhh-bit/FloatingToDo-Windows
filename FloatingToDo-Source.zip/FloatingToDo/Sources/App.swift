import AppKit
import SwiftUI
import ServiceManagement

#if !TESTING
@main struct FloatingTodoApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate
    var body: some Scene { Settings { EmptyView() } }
}
#endif
@MainActor final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate {
    var controller: WindowController!
    var statusItem: NSStatusItem!
    var loginItem: NSMenuItem!
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        let custom = ProcessInfo.processInfo.environment["FLOATING_TODO_DATA_FILE"].map { URL(fileURLWithPath: $0) }
        controller = WindowController(store: TaskStore(url: custom))
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        statusItem.button?.image = NSImage(systemSymbolName: "checklist", accessibilityDescription: "Floating To-Do")
        statusItem.button?.image?.isTemplate = true
        let menu = NSMenu(); menu.delegate = self
        item("Show Floating Widget", #selector(showWidget), in: menu)
        item("Open To-Do", #selector(openTodo), in: menu)
        item("Reset Widget Position", #selector(resetPosition), in: menu)
        menu.addItem(.separator())
        loginItem = item("Launch at Login", #selector(toggleLogin), in: menu)
        if #unavailable(macOS 13) { loginItem.title = "Launch at Login Settings…" }
        menu.addItem(.separator())
        let quit = item("Quit Floating To-Do", #selector(quit), in: menu); quit.keyEquivalent = "q"
        statusItem.menu = menu
        controller.showWidget()
    }
    @discardableResult private func item(_ title: String, _ action: Selector, in menu: NSMenu) -> NSMenuItem {
        let item = NSMenuItem(title: title, action: action, keyEquivalent: ""); item.target = self; menu.addItem(item); return item
    }
    func menuWillOpen(_ menu: NSMenu) {
        let names = [L("Show Floating Widget", "显示悬浮球"), L("Open To-Do", "打开待办"), L("Reset Widget Position", "重置悬浮球位置")]
        for (index, name) in names.enumerated() { menu.items[index].title = name }
        menu.items.last?.title = L("Quit Floating To-Do", "退出 Floating To-Do")
        if #available(macOS 13, *) { loginItem.title = L("Launch at Login", "开机启动") }
        else { loginItem.title = L("Launch at Login Settings…", "开机启动设置…") }
        if #available(macOS 13, *) { loginItem.state = SMAppService.mainApp.status == .enabled ? .on : .off }
    }
    @objc func showWidget() { controller.showWidget() }
    @objc func openTodo() { controller.openPanel() }
    @objc func resetPosition() { controller.resetPosition(); controller.showWidget() }
    @objc func quit() { NSApp.terminate(nil) }
    @objc func toggleLogin() {
        guard #available(macOS 13, *) else {
            let alert = NSAlert()
            alert.messageText = "Launch at Login on macOS Monterey"
            alert.informativeText = "Move Floating To-Do to Applications, then open System Preferences → Users & Groups → Login Items. Click + and select Floating To-Do. Remove it from that list to disable launch at login."
            alert.addButton(withTitle: "Open System Preferences")
            alert.addButton(withTitle: "Cancel")
            if alert.runModal() == .alertFirstButtonReturn {
                NSWorkspace.shared.open(URL(fileURLWithPath: "/System/Applications/System Preferences.app"))
            }
            return
        }
        do {
            if SMAppService.mainApp.status == .enabled { try SMAppService.mainApp.unregister() }
            else { try SMAppService.mainApp.register(); if SMAppService.mainApp.status == .requiresApproval { SMAppService.openSystemSettingsLoginItems() } }
        } catch {
            let alert = NSAlert(); alert.messageText = "Could not change Launch at Login"
            alert.informativeText = error.localizedDescription; alert.runModal()
        }
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { false }
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool { controller.showWidget(); return true }
}
