import AppKit
import SwiftUI

struct TimeWheel: NSViewRepresentable {
    let values: [String]
    @Binding var selection: Int
    let label: String
    var cancel: () -> Void = {}
    func makeNSView(context: Context) -> WheelView { let v = WheelView(); configure(v); return v }
    func updateNSView(_ view: WheelView, context: Context) { configure(view) }
    private func configure(_ view: WheelView) {
        view.cancel = cancel; view.values = values; view.changed = { selection = $0 }; view.setAccessibilityLabel(label)
        if view.selected != selection { view.selected = selection; view.offset = 0 }
        view.needsDisplay = true
    }
}
final class WheelView: NSView {
    var values: [String] = []
    var selected = 0
    var offset: CGFloat = 0
    var changed: ((Int) -> Void)?
    var cancel: (() -> Void)?
    private var snapTimer: Timer?
    private var lastDrag: CGFloat = 0
    private var didDrag = false
    override var acceptsFirstResponder: Bool { true }
    override var isFlipped: Bool { true }
    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        clipsToBounds = true
        setAccessibilityElement(true); setAccessibilityRole(.slider)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    override func accessibilityValue() -> Any? { values.indices.contains(selected) ? values[selected] : "" }
    override func accessibilityPerformIncrement() -> Bool { select(selected + 1); return true }
    override func accessibilityPerformDecrement() -> Bool { select(selected - 1); return true }
    override func draw(_ dirtyRect: NSRect) {
        let middle = bounds.midY
        NSColor.black.withAlphaComponent(0.055).setFill()
        NSBezierPath(roundedRect: NSRect(x: 2, y: middle - 15, width: bounds.width - 4, height: 30), xRadius: 6, yRadius: 6).fill()
        for i in values.indices {
            let y = middle + CGFloat(i - selected) * 30 - offset
            guard abs(y - middle) < 65 else { continue }
            let alpha = max(0.12, 1 - abs(y - middle) / 70)
            let attrs: [NSAttributedString.Key: Any] = [.font: AppTypography.native(17), .foregroundColor: NSColor(calibratedWhite: 0.22, alpha: alpha)]
            let string = values[i] as NSString; let size = string.size(withAttributes: attrs)
            string.draw(at: NSPoint(x: (bounds.width - size.width) / 2, y: y - size.height / 2), withAttributes: attrs)
        }
        if window?.firstResponder === self {
            NSColor.black.withAlphaComponent(0.25).setStroke()
            NSBezierPath(roundedRect: bounds.insetBy(dx: 1, dy: 1), xRadius: 7, yRadius: 7).stroke()
        }
    }
    func select(_ index: Int) {
        let next = max(0, min(values.count - 1, index))
        offset = 0; selected = next; changed?(next); needsDisplay = true
        NSAccessibility.post(element: self, notification: .valueChanged)
    }
    private func scroll(_ delta: CGFloat) {
        snapTimer?.invalidate(); offset += delta
        while offset >= 15 && selected < values.count - 1 { offset -= 30; selected += 1; changed?(selected) }
        while offset <= -15 && selected > 0 { offset += 30; selected -= 1; changed?(selected) }
        if selected == 0 { offset = max(0, offset) }
        if selected == values.count - 1 { offset = min(0, offset) }
        needsDisplay = true
        snapTimer = Timer.scheduledTimer(withTimeInterval: 0.12, repeats: false) { [weak self] _ in self?.snap() }
    }
    private func snap() {
        snapTimer?.invalidate()
        if NSWorkspace.shared.accessibilityDisplayShouldReduceMotion { offset = 0; needsDisplay = true; return }
        snapTimer = Timer.scheduledTimer(withTimeInterval: 1 / 60, repeats: true) { [weak self] timer in
            guard let self else { timer.invalidate(); return }
            self.offset *= 0.60; self.needsDisplay = true
            if abs(self.offset) < 0.2 { self.offset = 0; timer.invalidate() }
        }
    }
    override func scrollWheel(with event: NSEvent) { scroll(-event.scrollingDeltaY * (event.hasPreciseScrollingDeltas ? 1 : 9)) }
    override func mouseDown(with event: NSEvent) {
        window?.makeFirstResponder(self); lastDrag = convert(event.locationInWindow, from: nil).y; didDrag = false
    }
    override func mouseDragged(with event: NSEvent) {
        let y = convert(event.locationInWindow, from: nil).y; didDrag = true; scroll(lastDrag - y); lastDrag = y
    }
    override func mouseUp(with event: NSEvent) {
        let y = convert(event.locationInWindow, from: nil).y
        if !didDrag { select(selected + Int(((y - bounds.midY) / 30).rounded())) }
        snap()
    }
    override func keyDown(with event: NSEvent) {
        switch event.keyCode {
        case 53: cancel?()
        case 126: select(selected - 1)
        case 125: select(selected + 1)
        case 48: if event.modifierFlags.contains(.shift) { window?.selectPreviousKeyView(self) } else { window?.selectNextKeyView(self) }
        default: super.keyDown(with: event)
        }
    }
    override func becomeFirstResponder() -> Bool { needsDisplay = true; return true }
    override func resignFirstResponder() -> Bool { needsDisplay = true; return true }
}
