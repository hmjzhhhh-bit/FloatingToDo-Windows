$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command cargo -ErrorAction SilentlyContinue)) { throw 'Install Rust stable from https://rustup.rs, then reopen PowerShell.' }
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) { throw 'Install Node.js 22 LTS or newer, then run: npm install -g pnpm@11.25.0' }
function Run-Step([scriptblock]$Command) {
    & $Command
    if ($LASTEXITCODE -ne 0) { throw "Build command failed (exit $LASTEXITCODE)." }
}
Run-Step { pnpm install --frozen-lockfile }
Run-Step { pnpm test }
Run-Step { cargo test --locked --manifest-path src-tauri/Cargo.toml }
Run-Step { pnpm build:windows }
Write-Host 'Installer: src-tauri\target\release\bundle\nsis\*-setup.exe'
