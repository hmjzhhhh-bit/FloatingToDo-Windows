# Floating To-Do — Windows trial

Windows 10/11 x64 桌面试用版，使用 Tauri 2、Rust 和原生 HTML/CSS/JavaScript。现有 Swift macOS 项目独立保留。

## 功能

- 一个置顶窗口：64 × 64 圆形计数器 → 小圆角方形 → 400 × 460 任务面板。动画调整实际窗口尺寸；Windows 原生圆角区域裁掉外部点击区域。
- 拖动圆形浮窗或面板顶栏移动；点击圆形展开，× 或 Escape 收起。托盘菜单提供显示、打开、重置位置、开机启动和退出。
- To-Do、Completed、Cancelled 使用黑色 Courier New Regular 标签，选中项显示下划线。Windows 没有该字体时使用系统等宽字体。
- 新增、编辑、截止日期、日历、小时/分钟/AM-PM 滚动控件、完成、取消、恢复和逾期变灰。
- 拖动任务排序；键盘 Alt+↑/↓ 也可调整顺序。
- 归档页固定的垃圾桶进入多选模式，按数量确认永久删除；不会清空整个分类。
- 本地 JSON 原子保存，失败时保留原状态。无法读取的数据文件不会被覆盖。无账号、云同步或遥测。
- 安装包和托盘使用固定数字 3 图标；悬浮球数字为真实未完成任务数。

## 给朋友安装

GitHub Actions 成功后，在对应构建的 **Artifacts → FloatingToDo-Windows-x64** 下载 ZIP，解压得到 `*-setup.exe`，把安装程序发给朋友。

安装程序为当前用户安装应用，并在需要时下载 Microsoft WebView2 Runtime，因此首次安装可能需要联网。应用本身离线工作。试用包尚未做 Windows 代码签名，首次运行可能出现未知发布者提示；只分发和使用你确认来源的构建。

安装后启动应用，查找桌面圆形浮窗和系统托盘图标。退出从托盘菜单选择 **Quit**。Launch at Login 默认为关闭。

## 自动构建

项目根目录包含 `.github/workflows/windows.yml`。推送代码或在 GitHub **Actions → Build Windows trial → Run workflow** 手动运行，会执行前端测试、Rust 测试并生成 NSIS 安装包。工作流不会自动发布公开 Release。

## 在 Windows 本地构建

安装以下官方工具：

1. Node.js 22 LTS 或更高版本。
2. Microsoft C++ Build Tools，勾选 **Desktop development with C++** 和 Windows SDK。
3. Rust stable（MSVC 工具链），来自 https://rustup.rs。
4. WebView2 Runtime（Windows 11 通常已包含）。
5. 在终端运行 `npm install -g pnpm@11.25.0`。

打开 PowerShell，在项目目录运行：

```powershell
.\build-windows.ps1
```

输出位于 `src-tauri\target\release\bundle\nsis\`。开发运行：`pnpm install --frozen-lockfile`，然后 `pnpm dev`。

## 数据与测试

任务保存在 Tauri 的用户应用数据目录：Windows 通常为 `%APPDATA%\com.floatingtodo.windows\tasks.json`。位置另存为 `position.json`。复制 tasks.json 可以备份；不与 Mac 版自动共享数据格式。安装包不包含开发者或其他用户的任务。

测试可通过 `FLOATING_TODO_DATA_FILE` 指定单独的任务 JSON。网页预览仅在 URL 带有 `?preview=1` 时启用，使用独立 localStorage，不能替代 Windows 桌面验证。

```sh
pnpm test
cargo test --locked --manifest-path src-tauri/Cargo.toml
```

## 实现与验证范围

见 [TESTING.md](TESTING.md)。透明背景使用半透明表面，不声称完整复现 macOS 的原生磨砂效果。减少动画、减少透明度和高对比度通过系统媒体查询处理；具体 Windows/WebView2 行为需真机验证。跨显示器 DPI、原生拖动和安装器同样需 Windows 实测。

参考：[Tauri Windows 安装包](https://v2.tauri.app/distribute/windows-installer/)、[构建环境](https://v2.tauri.app/start/prerequisites/)、[系统托盘](https://v2.tauri.app/learn/system-tray/)。

## Version 1.3.1

Synced with the Mac UI: gear settings (font size, baseline offset, language, 12/24-hour clock); larger regular Courier New Latin text and a light Chinese fallback; outside-focus collapse; confirmed panel quit; right-click radial actions; quick add with deadline calendar; stable pointer-based drag sorting and edge scrolling; completed/cancelled drag-to-trash with animated hover and confirmation.

Windows uses PingFang SC only if already installed, otherwise Microsoft YaHei UI. No Apple font files are distributed. Native Windows runtime must be tested on Windows; the browser preview cannot validate window focus, GDI hit regions, or installation. The installer is unsigned.
