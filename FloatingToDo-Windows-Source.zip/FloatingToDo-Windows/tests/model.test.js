import test from 'node:test';
import assert from 'node:assert/strict';
import * as m from '../web/model.js';
const add=(tasks,id)=>m.add(tasks,`  Task ${id}  `,1234,id,100);
function fixture(){let tasks=[];for(const id of ['a','b','c','d','e'])tasks=add(tasks,id);tasks=m.transition(tasks,'b','completed',200);tasks=m.transition(tasks,'c','completed',200);tasks=m.transition(tasks,'d','cancelled',200);return tasks;}
test('create trims titles, rejects whitespace, retains dates',()=>{const t=add([],'a')[0];assert.equal(t.title,'Task a');assert.equal(t.deadline,1234);assert.throws(()=>m.add([],'  '));assert.equal(m.count([t]),1);});
test('transition and restore append to active list without clearing deadline',()=>{const t=m.transition(fixture(),'b','todo',300);assert.deepEqual(m.items(t,'todo').map(t=>t.id),['a','e','b']);assert.equal(t.find(t=>t.id==='b').deadline,1234);assert.equal(t.find(t=>t.id==='b').completedAt,null);});
test('selected completed deletion protects active, cancelled and unselected tasks',()=>{const t=fixture(),next=m.deleteArchived(t,new Set(['a','b','d']),'completed');assert.deepEqual(next.map(t=>t.id),['a','c','d','e']);assert.equal(m.count(next),m.count(t));assert.equal(t.length,5);});
test('cancelled deletion preserves other categories',()=>{const t=fixture(),next=m.deleteArchived(t,new Set(['a','b','d']),'cancelled');assert.deepEqual(next.map(t=>t.id),['a','b','c','e']);assert.equal(m.count(next),m.count(t));});
test('empty and forbidden deletion have no effect; stale restored IDs protected',()=>{const t=fixture();assert.deepEqual(m.deleteArchived(t,new Set(),'completed'),t);assert.deepEqual(m.deleteArchived(t,new Set(['a']),'todo'),t);const restored=m.transition(t,'d','todo');assert.deepEqual(m.deleteArchived(restored,new Set(['d']),'cancelled'),restored);});
test('editing preserves status and ordering',()=>{const t=fixture(),next=m.edit(t,'b','  Updated  ',null);assert.equal(next[1].title,'Updated');assert.equal(next[1].status,'completed');assert.equal(next[1].deadline,null);assert.equal(t[1].title,'Task b');});
test('reorder supports first and last, ignores archived or unknown IDs',()=>{const t=fixture();assert.deepEqual(m.items(m.move(t,'e','a'),'todo').map(t=>t.id),['e','a']);assert.deepEqual(m.items(m.move(t,'a',null),'todo').map(t=>t.id),['e','a']);assert.deepEqual(m.move(t,'a','b'),t);assert.deepEqual(m.move(t,'b',null),t);assert.deepEqual(m.move(t,'a','missing'),t);});
test('two-stage geometry starts circular and animates actual bounds',()=>{const area={x:0,y:0,width:1920,height:1040},a={x:100,y:100};assert.deepEqual(m.frame(0,a,area),{x:100,y:100,width:64,height:64,radius:32});assert.equal(m.frame(.2,a,area).width,64);assert.equal(m.frame(.2,a,area).radius,16);assert.equal(m.frame(1,a,area).width,400);assert.equal(m.frame(1,a,area).height,460);assert.ok(m.frame(.6,a,area).width>64);});
test('all geometry samples stay in negative-origin and small display work areas',()=>{for(const area of [{x:-1920,y:-300,width:1920,height:1040},{x:0,y:0,width:320,height:360}])for(const anchor of [{x:-10000,y:-10000},{x:99999,y:99999},{x:area.x+30,y:area.y+50}])for(let i=0;i<=100;i++){const f=m.frame(i/100,anchor,area);assert.ok(f.x>=area.x&&f.y>=area.y);assert.ok(f.x+f.width<=area.x+area.width+.001);assert.ok(f.y+f.height<=area.y+area.height+.001);}});
test('reverse path returns exact original anchor when it is on-screen',()=>{const a={x:1850,y:960},area={x:0,y:0,width:1920,height:1040};m.frame(1,a,area);const end=m.frame(0,a,area);assert.equal(end.x,a.x);assert.equal(end.y,a.y);});
test('settings reject corrupt data and clamp sizes',()=>{assert.equal(m.readPreferences('{bad').size,14);assert.deepEqual(m.readPreferences('{"size":99,"offset":-99,"language":"zh","hour24":true}'),{size:22,offset:-6,language:'zh',hour24:true});});
test('single drag can move fourth to first or first to last',()=>{let tasks=[];for(const id of ['a','b','c','d'])tasks=add(tasks,id);const before=m.dragTarget(10,[{id:'a',mid:30},{id:'b',mid:80},{id:'c',mid:130}]);assert.deepEqual(m.items(m.move(tasks,'d',before),'todo').map(t=>t.id),['d','a','b','c']);assert.equal(m.dragTarget(500,[{id:'b',mid:80}]),null);});
test('quick actions preserve bubble anchor and stay inside screen at all corners',()=>{const area={x:-1400,y:-200,width:1400,height:900};for(const anchor of [{x:-1400,y:-200},{x:-64,y:-200},{x:-1400,y:636},{x:-64,y:636}])for(const kind of ['actions','input','date']){const f=m.compactFrame(kind,anchor,area);assert.ok(f.x>=area.x&&f.y>=area.y&&f.x+f.width<=area.x+area.width&&f.y+f.height<=area.y+area.height);if(f.circles){assert.equal(f.x+f.circles[0].x,anchor.x+32);assert.equal(f.y+f.circles[0].y,anchor.y+32);for(const c of f.circles)assert.ok(c.x-c.r>=0&&c.y-c.r>=0&&c.x+c.r<=f.width&&c.y+c.r<=f.height);}}});
test('quick-add deadline uses the same persistent task model',()=>{const deadline=Date.now()+86400000;const tasks=m.add([],'中文 To-do',deadline,'quick');assert.equal(tasks[0].deadline,deadline);assert.equal(tasks[0].title,'中文 To-do');});

test('marquee selection intersects only touched rows and ignores a click',()=>{
 const row={left:10,top:10,right:110,bottom:40};
 assert.equal(m.selectionIntersects({left:0,top:0,right:120,bottom:90},row),true);
 assert.equal(m.selectionIntersects({left:0,top:50,right:120,bottom:90},row),false);
 assert.equal(m.selectionIntersects({left:20,top:20,right:20,bottom:20},row),false);
});

test('group reorder and cancel preserve current group order and other tasks',()=>{
 let tasks=[];for(const id of ['a','b','c','d','e'])tasks=add(tasks,id);
 tasks=m.moveGroup(tasks,new Set(['e','d']),'a');assert.deepEqual(m.items(tasks,'todo').map(t=>t.id),['d','e','a','b','c']);
 tasks=m.moveGroup(tasks,new Set(['a','d']),null);assert.deepEqual(m.items(tasks,'todo').map(t=>t.id),['e','b','c','d','a']);
 tasks=m.cancelGroup(tasks,new Set(['a','d']),200);assert.deepEqual(m.items(tasks,'todo').map(t=>t.id),['e','b','c']);
 assert.deepEqual(m.items(tasks,'cancelled').map(t=>t.id),['d','a']);assert.ok(m.items(tasks,'cancelled').every(t=>t.deadline===1234));
});
