const native=Boolean(window.__TAURI__);
export const preview=!native && new URLSearchParams(location.search).has('preview');
let fakeFrame={x:100,y:100,width:64,height:64};
export async function invoke(command,args={}) {
  if(native)return window.__TAURI__.core.invoke(command,args);
  if(!preview)throw Error('Open this application through Floating To-Do. Browser preview requires ?preview=1.');
  switch(command){
    case 'load_tasks': return JSON.parse(localStorage.getItem('floating-todo-preview')||'{"version":1,"revision":0,"tasks":[]}');
    case 'save_tasks': {const state={version:1,revision:args.revision+1,tasks:args.tasks};localStorage.setItem('floating-todo-preview',JSON.stringify(state));return state;}
    case 'geometry':return {anchor:{x:fakeFrame.x,y:fakeFrame.y},area:{x:0,y:0,width:1200,height:900}};
    case 'set_frame':fakeFrame=args;document.body.style.width=`${args.width}px`;document.body.style.height=`${args.height}px`;return;
    case 'show_widget':case 'save_anchor':case 'start_drag':return;
    default:throw Error(`Unknown command: ${command}`);
  }
}
export async function listen(event,callback){if(native)return window.__TAURI__.event.listen(event,callback);return ()=>{};}
