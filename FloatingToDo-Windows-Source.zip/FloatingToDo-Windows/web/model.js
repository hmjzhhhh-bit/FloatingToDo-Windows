export const statuses = ['todo', 'completed', 'cancelled'];
export const items = (tasks, status) => tasks.filter(t => t.status === status).sort((a,b) => a.position-b.position || a.createdAt-b.createdAt);
export const count = tasks => tasks.filter(t => t.status === 'todo').length;
const nextPosition = (tasks, status) => Math.max(-1, ...items(tasks,status).map(t=>t.position)) + 1;
function clean(title) { const value=title.trim(); if (!value) throw Error('Please enter a task title.'); return value; }
export function add(tasks, title, deadline=null, id=crypto.randomUUID(), now=Date.now()) {
  return [...tasks, {id,title:clean(title),deadline,status:'todo',createdAt:now,completedAt:null,cancelledAt:null,position:nextPosition(tasks,'todo')}];
}
export function edit(tasks,id,title,deadline) { return tasks.map(t=>t.id===id?{...t,title:clean(title),deadline}:t); }
export function transition(tasks,id,status,now=Date.now()) {
  if (!statuses.includes(status)) throw Error('Unknown category.');
  return tasks.map(t=>t.id===id && t.status!==status ? {...t,status,position:nextPosition(tasks,status),completedAt:status==='completed'?now:null,cancelledAt:status==='cancelled'?now:null}:t);
}
export function deleteArchived(tasks,ids,status) {
  if (!['completed','cancelled'].includes(status)) return tasks;
  return tasks.filter(t=>!(t.status===status && ids.has(t.id)));
}
export function move(tasks,id,before=null) {
  const ordered=items(tasks,'todo').map(t=>t.id);
  if (!ordered.includes(id) || id===before || (before!==null && !ordered.includes(before))) return tasks;
  ordered.splice(ordered.indexOf(id),1); ordered.splice(before===null?ordered.length:ordered.indexOf(before),0,id);
  return tasks.map(t=>t.status==='todo'?{...t,position:ordered.indexOf(t.id)}:t);
}
export function clamp(value,min,max) { return Math.max(min,Math.min(value,Math.max(min,max))); }
export function frame(progress, anchor, area) {
  const t=clamp((progress-0.2)/0.8,0,1), eased=t*t*(3-2*t);
  const width=64+(Math.min(400,area.width)-64)*eased, height=64+(Math.min(460,area.height)-64)*eased;
  return {x:clamp(anchor.x,area.x,area.x+area.width-width),y:clamp(anchor.y,area.y,area.y+area.height-height),width,height,radius:progress<0.2?32-16*progress/0.2:16+4*eased};
}
