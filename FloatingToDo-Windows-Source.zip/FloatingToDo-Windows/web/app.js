import * as model from './model.js';
import {invoke,listen,preview} from './bridge.js';
const $=id=>document.getElementById(id);
const icons={trash:'<path d="M3 5h14M7 5V2h6v3M5 5l1 13h8l1-13M8 8v7M12 8v7"/>',restore:'<path d="M7 4L2 9l5 5M2 9h10a4 4 0 0 1 0 8h-2"/>',square:'<rect x="3" y="3" width="14" height="14" rx="2"/>',check:'<rect x="3" y="3" width="14" height="14" rx="2"/><path d="m6 10 3 3 5-6"/>',minus:'<rect x="3" y="3" width="14" height="14" rx="2"/><path d="M6 10h8"/>',calendar:'<rect x="2" y="4" width="16" height="14" rx="2"/><path d="M6 2v5M14 2v5M2 9h16"/>'};
const icon=name=>`<svg viewBox="0 0 20 20" aria-hidden="true">${icons[name]}</svg>`;
$('deadline').innerHTML=icon('calendar');$('select-trash').innerHTML=icon('trash');
let state={version:1,revision:0,tasks:[]},tab='todo',selected=new Set(),selection=false,busy=false,loadFailed=false,draftDeadline=null,dragged=null;
let progress=0,target=0,animating=false,anchor,area,expandedFrame;
const reduceMotion=matchMedia('(prefers-reduced-motion: reduce)');
function error(e){$('error').textContent=String(e.message||e);$('error').hidden=false;if(!target)void morph(true);}
function formatDate(n){return new Intl.DateTimeFormat('en-US',{month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit'}).format(new Date(n));}
async function commit(change){
  if(busy||loadFailed)return false;
  busy=true;render();
  try {const tasks=change(state.tasks);state=await invoke('save_tasks',{tasks,revision:state.revision});$('error').hidden=true;return true;}
  catch(e){error(e);return false;}
  finally {busy=false;render();}
}
function button(label,name,action){const el=document.createElement('button');el.className='icon';el.title=label;el.setAttribute('aria-label',label);el.innerHTML=icon(name);el.disabled=busy||loadFailed;el.onclick=action;return el;}
function render(){
  const count=model.count(state.tasks);$('bubble').textContent=count;$('bubble').style.fontSize=`${count>999?18:26}px`;$('bubble').setAttribute('aria-label',`${count} unfinished tasks. Open task list`);
  const rows=model.items(state.tasks,tab),valid=new Set(rows.map(t=>t.id));selected=new Set([...selected].filter(id=>valid.has(id)));
  document.querySelectorAll('[data-tab]').forEach(b=>{if(b.dataset.tab===tab)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
  const scroll=$('list').scrollTop;$('list').replaceChildren();
  if(!rows.length){const e=document.createElement('p');e.className='empty';e.textContent=loadFailed?'Tasks unavailable.':tab==='todo'?'Nothing to do.':`No ${tab} tasks.`;$('list').append(e);}
  for(const task of rows){
    const row=document.createElement('div');row.className='row';row.dataset.id=task.id;row.setAttribute('role','listitem');
    if(selection){const check=document.createElement('input');check.type='checkbox';check.className='selector';check.checked=selected.has(task.id);check.disabled=busy;check.setAttribute('aria-label',`Select ${task.title} for deletion`);check.onchange=()=>{check.checked?selected.add(task.id):selected.delete(task.id);$('delete-selected').disabled=!selected.size||busy;};row.append(check);}
    const status=button(tab==='todo'?`Complete ${task.title}`:tab,tab==='todo'?'square':tab==='completed'?'check':'minus',()=>commit(tasks=>model.transition(tasks,task.id,'completed')));status.disabled=tab!=='todo'||busy||loadFailed;row.append(status);
    const text=document.createElement('button');text.className='task-text';text.title='Click to edit; drag to reorder. Alt+Up/Down moves a task.';text.disabled=busy||loadFailed;
    const title=document.createElement('span');title.className='task-title';title.textContent=task.title;text.append(title);
    if(task.deadline!==null){const date=document.createElement('span');date.className='task-date';date.textContent=formatDate(task.deadline);text.append(date);}
    text.onclick=()=>openEditor(task);text.draggable=tab==='todo'&&!busy;
    text.ondragstart=e=>{dragged=task.id;e.dataTransfer.setData('text/plain',task.id);e.dataTransfer.effectAllowed='move';row.classList.add('dragging');};
    text.ondragend=()=>{dragged=null;document.querySelectorAll('.drag-over,.dragging').forEach(el=>el.classList.remove('drag-over','dragging'));};
    text.onkeydown=e=>{if(tab==='todo'&&e.altKey&&['ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();const i=rows.findIndex(t=>t.id===task.id);if(e.key==='ArrowUp'&&i>0)void reorder(task.id,rows[i-1].id);if(e.key==='ArrowDown'&&i<rows.length-1)void reorder(task.id,rows[i+2]?.id??null);}};
    row.ondragover=e=>{if(tab==='todo'&&dragged&&dragged!==task.id){e.preventDefault();row.classList.add('drag-over');}};
    row.ondragleave=()=>row.classList.remove('drag-over');row.ondrop=e=>{e.preventDefault();e.stopPropagation();if(dragged&&tab==='todo')void reorder(dragged,task.id);};
    row.append(text,button(tab==='todo'?`Cancel ${task.title}`:`Restore ${task.title}`,tab==='todo'?'trash':'restore',()=>commit(tasks=>model.transition(tasks,task.id,tab==='todo'?'cancelled':'todo'))));$('list').append(row);
  }
  $('list').scrollTop=scroll;updateOverdue();
  $('composer').hidden=tab!=='todo';$('archive').hidden=tab==='todo';$('selection-hint').hidden=!selection;$('cancel-selection').hidden=!selection;$('delete-selected').hidden=!selection;$('select-trash').hidden=selection;
  $('delete-selected').disabled=!selected.size||busy;$('select-trash').disabled=!rows.length||busy||loadFailed;$('cancel-selection').disabled=busy;$('add').disabled=busy||loadFailed||!$('new-title').value.trim();$('deadline').disabled=busy||loadFailed;
  $('draft-date').hidden=draftDeadline===null;$('draft-date').textContent=draftDeadline===null?'':formatDate(draftDeadline);
}
async function reorder(id,before){if(await commit(tasks=>model.move(tasks,id,before))){[...$('list').children].find(el=>el.dataset.id===id)?.querySelector('.task-text')?.focus();}}
function updateOverdue(){const now=Date.now();for(const row of $('list').children){const task=state.tasks.find(t=>t.id===row.dataset.id);row.classList.toggle('overdue',Boolean(task&&task.status==='todo'&&task.deadline!==null&&task.deadline<now));}}
setInterval(updateOverdue,1000);
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;selected.clear();selection=false;render();$('list').scrollTop=0;});
$('new-title').oninput=()=>{$('add').disabled=busy||loadFailed||!$('new-title').value.trim();};
$('composer').onsubmit=async e=>{e.preventDefault();const title=$('new-title').value;if(!title.trim())return;if(await commit(tasks=>model.add(tasks,title,draftDeadline))){$('new-title').value='';draftDeadline=null;render();$('new-title').focus();}};
$('list').ondragover=e=>{if(dragged&&tab==='todo')e.preventDefault();};$('list').ondrop=e=>{e.preventDefault();if(dragged&&tab==='todo')void reorder(dragged,null);};
$('select-trash').onclick=()=>{selection=true;render();};$('cancel-selection').onclick=()=>{selection=false;selected.clear();render();};
let pending;
$('delete-selected').onclick=()=>{pending={ids:new Set(selected),status:tab};$('confirm-title').textContent=`Permanently delete ${pending.ids.size} ${pending.ids.size===1?'task':'tasks'}?`;$('confirm').showModal();$('cancel-delete').focus();};
$('cancel-delete').onclick=()=>{$('confirm').close();pending=null;};
$('confirm-delete').onclick=async()=>{if(!pending||busy)return;$('confirm-delete').disabled=true;const snapshot=pending;if(await commit(tasks=>model.deleteArchived(tasks,snapshot.ids,snapshot.status))){selection=false;selected.clear();pending=null;$('confirm').close();render();}$('confirm-delete').disabled=false;};
let editing=null,chosen=new Date(),month=new Date();
function openEditor(task=null){editing=task;$('editor-title').textContent=task?'Edit task':'Choose deadline';$('title-label').hidden=!task;$('edit-title').required=Boolean(task);$('edit-title').value=task?.title||'';const deadline=task?task.deadline:draftDeadline;$('has-deadline').checked=deadline!==null;chosen=new Date(deadline??Date.now());chosen.setSeconds(0,0);month=new Date(chosen.getFullYear(),chosen.getMonth(),1);renderDate();$('editor').showModal();(task?$('edit-title'):$('has-deadline')).focus();}
$('deadline').onclick=()=>openEditor();$('cancel-edit').onclick=()=>$('editor').close();$('has-deadline').onchange=renderDate;
$('prev-month').onclick=()=>{month.setMonth(month.getMonth()-1);renderDate();};$('next-month').onclick=()=>{month.setMonth(month.getMonth()+1);renderDate();};
function renderDate(){
  $('date-controls').hidden=!$('has-deadline').checked;$('month-name').textContent=month.toLocaleDateString('en-US',{month:'long',year:'numeric'});$('calendar').replaceChildren();
  for(let i=0;i<month.getDay();i++)$('calendar').append(document.createElement('span'));
  for(let day=1;day<=new Date(month.getFullYear(),month.getMonth()+1,0).getDate();day++){
    const b=document.createElement('button');b.type='button';b.textContent=day;b.setAttribute('aria-label',new Date(month.getFullYear(),month.getMonth(),day).toLocaleDateString('en-US',{dateStyle:'long'}));b.setAttribute('aria-pressed',String(chosen.getDate()===day&&chosen.getMonth()===month.getMonth()&&chosen.getFullYear()===month.getFullYear()));
    b.onclick=()=>{chosen.setFullYear(month.getFullYear(),month.getMonth(),day);renderDate();};$('calendar').append(b);
  }
  if(!$('wheels').children.length){makeWheel('Hour',12,()=>chosen.getHours()%12,h=>chosen.setHours((chosen.getHours()>=12?12:0)+h),h=>String(h===0?12:h).padStart(2,'0'));makeWheel('Minute',60,()=>chosen.getMinutes(),m=>chosen.setMinutes(m),m=>String(m).padStart(2,'0'));makeWheel('AM/PM',2,()=>chosen.getHours()>=12?1:0,p=>chosen.setHours(chosen.getHours()%12+p*12),p=>p?'PM':'AM');}
  document.querySelectorAll('.wheel-control').forEach(el=>el.refresh());
}
function makeWheel(label,length,get,set,format){
  const wrap=document.createElement('div');wrap.className='wheel';const name=document.createElement('label');name.textContent=label;const control=document.createElement('div');control.className='wheel-control';control.tabIndex=0;control.setAttribute('role','spinbutton');control.setAttribute('aria-label',label);control.setAttribute('aria-valuemin',label==='Hour'?1:0);control.setAttribute('aria-valuemax',label==='Hour'?12:length-1);
  const prev=document.createElement('button'),next=document.createElement('button'),value=document.createElement('output');prev.type=next.type='button';prev.tabIndex=next.tabIndex=-1;prev.setAttribute('aria-label',`Decrease ${label}`);next.setAttribute('aria-label',`Increase ${label}`);
  control.refresh=()=>{const n=get();prev.textContent=format((n+length-1)%length);next.textContent=format((n+1)%length);value.textContent=format(n);control.setAttribute('aria-valuenow',label==='Hour'?(n||12):n);control.setAttribute('aria-valuetext',format(n));};
  const change=delta=>{set((get()+delta+length)%length);control.refresh();};prev.onclick=()=>change(-1);next.onclick=()=>change(1);control.onkeydown=e=>{if(['ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();change(e.key==='ArrowUp'?-1:1);}};
  let delta=0;control.addEventListener('wheel',e=>{e.preventDefault();delta+=e.deltaY;if(Math.abs(delta)>=25){change(Math.sign(delta));delta=0;}},{passive:false});control.append(prev,value,next);wrap.append(name,control);$('wheels').append(wrap);
}
$('edit-form').onsubmit=async e=>{e.preventDefault();const deadline=$('has-deadline').checked?chosen.getTime():null;if(editing){if(await commit(tasks=>model.edit(tasks,editing.id,$('edit-title').value,deadline)))$('editor').close();}else{draftDeadline=deadline;$('editor').close();render();}};
async function syncAnchor(){const g=await invoke('geometry');area=g.area;if(progress===1&&expandedFrame){anchor={x:anchor.x+g.anchor.x-expandedFrame.x,y:anchor.y+g.anchor.y-expandedFrame.y};expandedFrame={...expandedFrame,...g.anchor};}else if(progress===0)anchor=g.anchor;}
async function morph(open){
  target=open?1:0;if(animating)return;animating=true;
  try{
    await syncAnchor();document.body.classList.add('morph');$('panel').inert=true;$('bubble').inert=true;
    let last=performance.now();
    while(progress!==target){const now=performance.now();const step=reduceMotion.matches?1:Math.min(40,now-last)/240;last=now;progress=target>progress?Math.min(target,progress+step):Math.max(target,progress-step);const f=model.frame(progress,anchor,area);await invoke('set_frame',f);$('surface').style.borderRadius=`${f.radius}px`;expandedFrame=progress===1?f:expandedFrame;if(progress!==target)await new Promise(requestAnimationFrame);}
    if(progress===0){anchor=model.frame(0,anchor,area);await invoke('save_anchor',{point:{x:anchor.x,y:anchor.y}});}
  }catch(e){$('error').textContent=`Window update failed: ${e}`;$('error').hidden=false;}
  finally{animating=false;document.body.classList.remove('morph');document.body.classList.toggle('expanded',progress===1);$('panel').inert=progress!==1;$('bubble').inert=progress!==0;if(progress===1)$('collapse').focus();else $('bubble').focus();if(progress!==target)void morph(target===1);}
}
$('collapse').onclick=()=>morph(false);
let pointer;
$('bubble').onpointerdown=e=>{if(e.button===0)pointer={x:e.screenX,y:e.screenY};};
$('bubble').onpointermove=async e=>{if(pointer&&e.buttons===1&&Math.hypot(e.screenX-pointer.x,e.screenY-pointer.y)>5){pointer=null;try{await invoke('start_drag');await syncAnchor();await invoke('save_anchor',{point:anchor});}catch(e){error(e);}}};
$('bubble').onpointerup=()=>{if(pointer){pointer=null;void morph(true);}};
$('bubble').onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();void morph(true);}};
$('dragbar').onpointerdown=async e=>{if(e.target.closest('button')||e.button!==0||animating)return;try{await invoke('start_drag');await syncAnchor();await invoke('save_anchor',{point:anchor});}catch(e){error(e);}};
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('editor').open&&!$('confirm').open){e.preventDefault();void morph(false);}});
async function resetPosition(){if(animating)return;$('editor').close();$('confirm').close();pending=null;const g=await invoke('geometry');area=g.area;anchor={x:area.x+area.width-84,y:area.y+20};progress=0;target=0;await invoke('set_frame',model.frame(0,anchor,area));$('surface').style.borderRadius='32px';document.body.classList.remove('expanded');$('panel').inert=true;$('bubble').inert=false;await invoke('save_anchor',{point:anchor});}
async function boot(){
  if(preview)document.body.classList.add('preview');
  await listen('open-panel',()=>void morph(true));await listen('reset-position',()=>void resetPosition().catch(error));await listen('app-error',e=>error(e.payload));
  const g=await invoke('geometry');anchor=g.anchor;area=g.area;const f=model.frame(0,anchor,area);anchor={x:f.x,y:f.y};await invoke('set_frame',f);
  try{state=await invoke('load_tasks');}catch(e){loadFailed=true;$('error').textContent=String(e);$('error').hidden=false;}
  render();await invoke('show_widget');if(loadFailed||preview)await morph(true);
}
boot().catch(e=>{$('error').textContent=String(e);$('error').hidden=false;document.body.classList.add('expanded');$('panel').inert=false;});
