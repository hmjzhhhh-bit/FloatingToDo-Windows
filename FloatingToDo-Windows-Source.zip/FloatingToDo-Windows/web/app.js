import * as model from './model.js';
import {invoke,listen,preview} from './bridge.js';
const $=id=>document.getElementById(id);
const icons={trash:'<path d="M3 5h14M7 5V2h6v3M5 5l1 13h8l1-13M8 8v7M12 8v7"/>',restore:'<path d="M7 4L2 9l5 5M2 9h10a4 4 0 0 1 0 8h-2"/>',square:'<rect x="3" y="3" width="14" height="14" rx="2"/>',check:'<rect x="3" y="3" width="14" height="14" rx="2"/><path d="m6 10 3 3 5-6"/>',minus:'<rect x="3" y="3" width="14" height="14" rx="2"/><path d="M6 10h8"/>',calendar:'<rect x="2" y="4" width="16" height="14" rx="2"/><path d="M6 2v5M14 2v5M2 9h16"/>'};
const icon=name=>`<svg viewBox="0 0 20 20" aria-hidden="true">${icons[name]}</svg>`;
$('deadline').innerHTML=icon('calendar');$('trash-target').innerHTML=icon('trash');$('quick-deadline').innerHTML=icon('calendar');
let state={version:1,revision:0,tasks:[]},tab='todo',busy=false,loadFailed=false,draftDeadline=null,quickDeadline=null,dragged=null;
let progress=0,target=0,animating=false,anchor,area,expandedFrame;
let compact=null,compactBusy=false,editorSource='main',suppressClickUntil=0;
let prefs=model.readPreferences(localStorage.getItem('floating-todo-settings'));
const tr=(en,zh)=>prefs.language==='zh'?zh:en;
const reduceMotion=matchMedia('(prefers-reduced-motion: reduce)');
function error(e){$('error').textContent=String(e.message||e);$('error').hidden=false;if(!target)void morph(true);}
function formatDate(n){return new Intl.DateTimeFormat(prefs.language==='zh'?'zh-CN':'en-US',{month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit',hour12:!prefs.hour24}).format(new Date(n));}
async function commit(change){
  if(busy||loadFailed)return false;
  busy=true;render();
  try {const tasks=change(state.tasks);state=await invoke('save_tasks',{tasks,revision:state.revision});$('error').hidden=true;return true;}
  catch(e){error(e);return false;}
  finally {busy=false;render();}
}
function button(label,name,action){const el=document.createElement('button');el.className='icon';el.title=label;el.setAttribute('aria-label',label);el.innerHTML=icon(name);el.disabled=busy||loadFailed;el.onclick=action;return el;}
function render(){
  const count=model.count(state.tasks);$('bubble').textContent=count;$('bubble').style.fontSize=`${count>999?18:26}px`;$('bubble').setAttribute('aria-label',`${count} unfinished tasks. Open task list`);
  const rows=model.items(state.tasks,tab);
  document.querySelectorAll('[data-tab]').forEach(b=>{if(b.dataset.tab===tab)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
  const scroll=$('list').scrollTop;$('list').replaceChildren();
  if(!rows.length){const e=document.createElement('p');e.className='empty';e.textContent=loadFailed?tr('Tasks unavailable.','待办无法读取。'):tab==='todo'?tr('Nothing to do.','暂无待办。'):tab==='completed'?tr('No completed tasks.','暂无已完成待办。'):tr('No cancelled tasks.','暂无已取消待办。');$('list').append(e);}
  for(const task of rows){
    const row=document.createElement('div');row.className='row';row.dataset.id=task.id;row.setAttribute('role','listitem');
    const status=button(tab==='todo'?`Complete ${task.title}`:tab,tab==='todo'?'square':tab==='completed'?'check':'minus',()=>commit(tasks=>model.transition(tasks,task.id,'completed')));status.disabled=tab!=='todo'||busy||loadFailed;row.append(status);
    const text=document.createElement('button');text.className='task-text';text.title='Click to edit; drag to reorder. Alt+Up/Down moves a task.';text.disabled=busy||loadFailed;
    const title=document.createElement('span');title.className='task-title';title.textContent=task.title;text.append(title);
    if(task.deadline!==null){const date=document.createElement('span');date.className='task-date';date.textContent=formatDate(task.deadline);text.append(date);}
    text.onclick=()=>{if(performance.now()>suppressClickUntil)openEditor(task);};text.onpointerdown=e=>beginTaskDrag(e,task,row,text);
    text.onkeydown=e=>{if(tab==='todo'&&e.altKey&&['ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();const i=rows.findIndex(t=>t.id===task.id);if(e.key==='ArrowUp'&&i>0)void reorder(task.id,rows[i-1].id);if(e.key==='ArrowDown'&&i<rows.length-1)void reorder(task.id,rows[i+2]?.id??null);}};
    row.append(text,button(tab==='todo'?`Cancel ${task.title}`:`Restore ${task.title}`,tab==='todo'?'trash':'restore',()=>commit(tasks=>model.transition(tasks,task.id,tab==='todo'?'cancelled':'todo'))));$('list').append(row);
  }
  $('list').scrollTop=scroll;updateOverdue();
  $('composer').hidden=tab!=='todo';$('archive').hidden=tab==='todo';
  $('add').disabled=busy||loadFailed||!$('new-title').value.trim();$('deadline').disabled=busy||loadFailed;
  $('quick-save').disabled=busy||loadFailed||!$('quick-title').value.trim();
  $('quick-date').textContent=quickDeadline===null?'':formatDate(quickDeadline);
  localize();
  $('draft-date').hidden=draftDeadline===null;$('draft-date').textContent=draftDeadline===null?'':formatDate(draftDeadline);
}
async function reorder(id,before){if(await commit(tasks=>model.move(tasks,id,before))){[...$('list').children].find(el=>el.dataset.id===id)?.querySelector('.task-text')?.focus();}}
function updateOverdue(){const now=Date.now();for(const row of $('list').children){const task=state.tasks.find(t=>t.id===row.dataset.id);row.classList.toggle('overdue',Boolean(task&&task.status==='todo'&&task.deadline!==null&&task.deadline<now));}}
setInterval(updateOverdue,1000);
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;render();$('list').scrollTop=0;});
$('new-title').oninput=()=>{$('add').disabled=busy||loadFailed||!$('new-title').value.trim();};
$('composer').onsubmit=async e=>{e.preventDefault();const title=$('new-title').value;if(!title.trim())return;if(await commit(tasks=>model.add(tasks,title,draftDeadline))){$('new-title').value='';draftDeadline=null;render();$('new-title').focus();}};
let pending;
function confirmDeletion(id){pending={ids:new Set([id]),status:tab};$('confirm-title').textContent=tr('Permanently delete this task?','永久删除这条待办？');$('confirm').showModal();$('cancel-delete').focus();}
$('cancel-delete').onclick=()=>{$('confirm').close();pending=null;};
$('confirm-delete').onclick=async()=>{if(!pending||busy)return;$('confirm-delete').disabled=true;const snapshot=pending;if(await commit(tasks=>model.deleteArchived(tasks,snapshot.ids,snapshot.status))){pending=null;$('confirm').close();render();}$('confirm-delete').disabled=false;};
let editing=null,chosen=new Date(),month=new Date();
function openEditor(task=null,source='main'){editorSource=source;editing=task;$('editor-title').textContent=task?tr('Edit task','编辑待办'):tr('Choose deadline','选择截止时间');$('title-label').hidden=!task;$('edit-title').required=Boolean(task);$('edit-title').value=task?.title||'';const deadline=task?task.deadline:(source==='quick'?quickDeadline:draftDeadline);$('has-deadline').checked=deadline!==null;chosen=new Date(deadline??Date.now());chosen.setSeconds(0,0);month=new Date(chosen.getFullYear(),chosen.getMonth(),1);renderDate();$('editor').showModal();(task?$('edit-title'):$('has-deadline')).focus();}
$('deadline').onclick=()=>openEditor();$('cancel-edit').onclick=()=>closeEditor();$('has-deadline').onchange=renderDate;
$('prev-month').onclick=()=>{month.setMonth(month.getMonth()-1);renderDate();};$('next-month').onclick=()=>{month.setMonth(month.getMonth()+1);renderDate();};
function renderDate(){
  $('date-controls').hidden=!$('has-deadline').checked;$('month-name').textContent=month.toLocaleDateString(prefs.language==='zh'?'zh-CN':'en-US',{month:'long',year:'numeric'});$('calendar').replaceChildren();
  for(let i=0;i<month.getDay();i++)$('calendar').append(document.createElement('span'));
  for(let day=1;day<=new Date(month.getFullYear(),month.getMonth()+1,0).getDate();day++){
    const b=document.createElement('button');b.type='button';b.textContent=day;b.setAttribute('aria-label',new Date(month.getFullYear(),month.getMonth(),day).toLocaleDateString(prefs.language==='zh'?'zh-CN':'en-US',{dateStyle:'long'}));b.setAttribute('aria-pressed',String(chosen.getDate()===day&&chosen.getMonth()===month.getMonth()&&chosen.getFullYear()===month.getFullYear()));
    b.onclick=()=>{chosen.setFullYear(month.getFullYear(),month.getMonth(),day);renderDate();};$('calendar').append(b);
  }
  if(!$('wheels').children.length){
    if(prefs.hour24)makeWheel(tr('Hour','时'),24,()=>chosen.getHours(),h=>chosen.setHours(h),h=>String(h).padStart(2,'0'));
    else makeWheel(tr('Hour','时'),12,()=>chosen.getHours()%12,h=>chosen.setHours((chosen.getHours()>=12?12:0)+h),h=>String(h===0?12:h).padStart(2,'0'));
    makeWheel(tr('Minute','分'),60,()=>chosen.getMinutes(),m=>chosen.setMinutes(m),m=>String(m).padStart(2,'0'));
    if(!prefs.hour24)makeWheel('AM/PM',2,()=>chosen.getHours()>=12?1:0,p=>chosen.setHours(chosen.getHours()%12+p*12),p=>p?'PM':'AM');
  }
  document.querySelectorAll('.wheel-control').forEach(el=>el.refresh());
}
function makeWheel(label,length,get,set,format){
  const wrap=document.createElement('div');wrap.className='wheel';const name=document.createElement('label');name.textContent=label;const control=document.createElement('div');control.className='wheel-control';control.tabIndex=0;control.setAttribute('role','spinbutton');control.setAttribute('aria-label',label);control.setAttribute('aria-valuemin',length===12?1:0);control.setAttribute('aria-valuemax',length===12?12:length-1);
  const prev=document.createElement('button'),next=document.createElement('button'),value=document.createElement('output');prev.type=next.type='button';prev.tabIndex=next.tabIndex=-1;prev.setAttribute('aria-label',`Decrease ${label}`);next.setAttribute('aria-label',`Increase ${label}`);
  control.refresh=()=>{const n=get();prev.textContent=format((n+length-1)%length);next.textContent=format((n+1)%length);value.textContent=format(n);control.setAttribute('aria-valuenow',length===12?(n||12):n);control.setAttribute('aria-valuetext',format(n));};
  const change=delta=>{set((get()+delta+length)%length);control.refresh();};prev.onclick=()=>change(-1);next.onclick=()=>change(1);control.onkeydown=e=>{if(['ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();change(e.key==='ArrowUp'?-1:1);}};
  let delta=0;control.addEventListener('wheel',e=>{e.preventDefault();delta+=e.deltaY;if(Math.abs(delta)>=25){change(Math.sign(delta));delta=0;}},{passive:false});control.append(prev,value,next);wrap.append(name,control);$('wheels').append(wrap);
}
$('edit-form').onsubmit=async e=>{e.preventDefault();const deadline=$('has-deadline').checked?chosen.getTime():null;if(editing){if(await commit(tasks=>model.edit(tasks,editing.id,$('edit-title').value,deadline)))$('editor').close();}else{if(editorSource==='quick')quickDeadline=deadline;else draftDeadline=deadline;closeEditor();render();}};
async function syncAnchor(){const g=await invoke('geometry');area=g.area;if(progress===1&&expandedFrame){anchor={x:anchor.x+g.anchor.x-expandedFrame.x,y:anchor.y+g.anchor.y-expandedFrame.y};expandedFrame={...expandedFrame,...g.anchor};}else if(progress===0)anchor=g.anchor;}
async function morph(open){
  if(compact){await dismissCompact();}
  target=open?1:0;if(animating)return;animating=true;
  try{
    await syncAnchor();document.body.classList.add('morph');$('panel').inert=true;$('bubble').inert=true;
    let last=performance.now();
    while(progress!==target){const now=performance.now();const step=reduceMotion.matches?1:Math.min(40,now-last)/240;last=now;progress=target>progress?Math.min(target,progress+step):Math.max(target,progress-step);const f=model.frame(progress,anchor,area);await invoke('set_frame',f);$('surface').style.borderRadius=`${f.radius}px`;expandedFrame=progress===1?f:expandedFrame;if(progress!==target)await new Promise(requestAnimationFrame);}
    if(progress===0){anchor=model.frame(0,anchor,area);await invoke('save_anchor',{point:{x:anchor.x,y:anchor.y}});}
  }catch(e){$('error').textContent=`Window update failed: ${e}`;$('error').hidden=false;}
  finally{animating=false;document.body.classList.remove('morph');document.body.classList.toggle('expanded',progress===1);$('panel').inert=progress!==1;$('bubble').inert=progress!==0;if(progress===1)$('collapse').focus();else $('bubble').focus();if(progress!==target)void morph(target===1);}
}
$('collapse').onclick=()=>askQuit();
let pointer;
$('bubble').onpointerdown=e=>{if(e.button===0)pointer={x:e.screenX,y:e.screenY};};
$('bubble').onpointermove=async e=>{if(pointer&&e.buttons===1&&Math.hypot(e.screenX-pointer.x,e.screenY-pointer.y)>5){pointer=null;try{await invoke('start_drag');await syncAnchor();await invoke('save_anchor',{point:anchor});}catch(e){error(e);}}};
$('bubble').onpointerup=e=>{if(e.button===0&&pointer){pointer=null;void morph(true);}};
$('bubble').onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();void morph(true);}};
$('dragbar').onpointerdown=async e=>{if(e.target.closest('button')||e.button!==0||animating)return;try{await invoke('start_drag');await syncAnchor();await invoke('save_anchor',{point:anchor});}catch(e){error(e);}};
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!document.querySelector('dialog[open]')){e.preventDefault();void morph(false);}});
async function resetPosition(){if(animating)return;$('editor').close();$('confirm').close();pending=null;const g=await invoke('geometry');area=g.area;anchor={x:area.x+area.width-84,y:area.y+20};progress=0;target=0;await invoke('set_frame',model.frame(0,anchor,area));$('surface').style.borderRadius='32px';document.body.classList.remove('expanded');$('panel').inert=true;$('bubble').inert=false;await invoke('save_anchor',{point:anchor});}
async function boot(){
  if(preview)document.body.classList.add('preview');
  await listen('window-blur',()=>{if(!document.querySelector('dialog[open]'))void morph(false);});
  await listen('open-panel',()=>void morph(true));await listen('reset-position',()=>void resetPosition().catch(error));await listen('app-error',e=>error(e.payload));
  const g=await invoke('geometry');anchor=g.anchor;area=g.area;const f=model.frame(0,anchor,area);anchor={x:f.x,y:f.y};await invoke('set_frame',f);
  try{state=await invoke('load_tasks');}catch(e){loadFailed=true;$('error').textContent=String(e);$('error').hidden=false;}
  applyPreferences();render();await invoke('show_widget');if(loadFailed||preview)await morph(true);
}
function localize(){
  const labels={todo:tr('To-Do','待办'),completed:tr('Completed','已完成'),cancelled:tr('Cancelled','已取消')};
  document.documentElement.lang=prefs.language==='zh'?'zh-CN':'en';
  document.querySelectorAll('[data-tab]').forEach(b=>b.textContent=labels[b.dataset.tab]);
  const texts={'trash-hint':tr('Drag a task here to delete','拖到垃圾桶删除'),'quick-heading':tr('Add new to-do','快速添加待办'),'settings-title':tr('Settings','设置'),'size-label':tr('Task font size','待办字号'),'offset-label':tr('Text vertical alignment','文字上下微调'),'language-label':tr('Language','语言'),'time-label':tr('Time format','时间格式'),'close-settings':tr('Done','完成'),'quit-title':tr('Quit Floating To-Do?','退出 Floating To-Do？'),'quit-hint':tr('Your saved tasks will be here when you reopen the app.','已保存的待办会保留，下次打开仍可查看。'),'cancel-quit':tr('Cancel','取消'),'do-quit':tr('Quit','退出'),'cancel-delete':tr('Cancel','取消'),'confirm-delete':tr('Delete','删除'),'cancel-edit':tr('Cancel','取消')};
  for(const [id,text] of Object.entries(texts))$(id).textContent=text;
  $('new-title').placeholder=tr('Add new to-do...','添加待办…');$('quick-title').placeholder=tr('What needs doing?','想做些什么？');
  $('confirm').querySelector('p').textContent=tr('This cannot be undone.','此操作无法撤销。');
  $('edit-form').querySelector('[type=submit]').textContent=tr('Save','保存');
  $('title-label').firstChild.textContent=tr('Title','内容');$('has-deadline').parentElement.lastChild.textContent=tr('Deadline','截止时间');
  $('weekdays').replaceChildren(...(prefs.language==='zh'?['日','一','二','三','四','五','六']:['Su','Mo','Tu','We','Th','Fr','Sa']).map(t=>{const e=document.createElement('span');e.textContent=t;return e;}));
  for(const [id,en,zh] of [['quick-quit','Quit','退出'],['quick-add','Add new to-do','添加待办'],['settings-button','Settings','设置'],['collapse','Quit','退出'],['deadline','Choose deadline','选择截止时间'],['quick-deadline','Choose deadline','选择截止时间']]){$(id).title=tr(en,zh);$(id).setAttribute('aria-label',tr(en,zh));}
}
function applyPreferences(){
  document.documentElement.style.setProperty('--task-size',prefs.size+'px');document.documentElement.style.setProperty('--text-offset',prefs.offset+'px');
  $('font-size').value=prefs.size;$('text-offset').value=prefs.offset;$('language').value=prefs.language;$('time-format').value=prefs.hour24?'24':'12';
  $('size-value').textContent=prefs.size;$('offset-value').textContent=prefs.offset;localize();
  void invoke('set_language',{chinese:prefs.language==='zh'}).catch(error);
}
$('settings-button').onclick=()=>{$('settings').showModal();};$('close-settings').onclick=()=>$('settings').close();
for(const id of ['font-size','text-offset','language','time-format'])$(id).oninput=()=>{
  prefs=model.readPreferences(JSON.stringify({size:+$('font-size').value,offset:+$('text-offset').value,language:$('language').value,hour24:$('time-format').value==='24'}));
  try{localStorage.setItem('floating-todo-settings',JSON.stringify(prefs));}catch(e){error(e);}
  $('wheels').replaceChildren();applyPreferences();render();
};
async function askQuit(){if(compact)await showCompact('input');$('quit-confirm').showModal();$('cancel-quit').focus();}
$('cancel-quit').onclick=()=>$('quit-confirm').close();$('do-quit').onclick=()=>void invoke('quit_app').catch(error);
async function showCompact(kind){
  if(compactBusy||animating)return;compactBusy=true;
  try{
    if(!compact)await syncAnchor();compact=kind;const f=model.compactFrame(kind,anchor,area);
    await invoke('set_frame',f);document.body.classList.remove('expanded');document.body.classList.add('compact');document.body.classList.toggle('radial',kind==='actions');
    $('panel').inert=true;$('bubble').inert=kind!=='actions';$('quick-actions').hidden=kind!=='actions';$('quick-input').hidden=kind==='actions';
    $('surface').style.borderRadius=kind==='actions'?'0':'18px';
    if(kind==='actions'){
      const [bubble,quit,add]=f.circles;
      for(const [id,c] of [['bubble',bubble],['quick-quit',quit],['quick-add',add]]){const el=$(id);el.style.left=(c.x-c.r)+'px';el.style.top=(c.y-c.r)+'px';}
    }else{$('bubble').style.left='';$('bubble').style.top='';$('quick-title').focus();}
    await invoke('focus_window');
  }catch(e){error(e);}finally{compactBusy=false;}
}
async function dismissCompact(){
  if(!compact)return;compact=null;$('quick-actions').hidden=true;$('quick-input').hidden=true;document.body.classList.remove('compact','radial');
  $('bubble').style.left='';$('bubble').style.top='';await invoke('set_frame',model.frame(0,anchor,area));$('surface').style.borderRadius='32px';progress=target=0;$('bubble').inert=false;
}
$('bubble').oncontextmenu=e=>{e.preventDefault();pointer=null;if(compact)void dismissCompact();else void showCompact('actions');};
$('quick-add').onclick=()=>void showCompact('input');$('quick-quit').onclick=()=>void askQuit();
$('quick-title').oninput=()=>{$('quick-save').disabled=busy||loadFailed||!$('quick-title').value.trim();};
$('quick-deadline').onclick=async()=>{await showCompact('date');openEditor(null,'quick');};
function closeEditor(){$('editor').close();if(editorSource==='quick')void showCompact('input');}
$('editor').addEventListener('cancel',()=>{if(editorSource==='quick')void showCompact('input');});
$('quick-form').onsubmit=async e=>{e.preventDefault();const title=$('quick-title').value;if(!title.trim())return;if(await commit(tasks=>model.add(tasks,title,quickDeadline))){$('quick-title').value='';quickDeadline=null;await dismissCompact();}};
let taskDrag=null;
function clearTaskDrag(){
  if(!taskDrag)return;cancelAnimationFrame(taskDrag.raf);taskDrag.ghost?.remove();taskDrag=null;dragged=null;
  $('trash-target').classList.remove('targeted');document.querySelectorAll('.drag-over,.dragging').forEach(e=>e.classList.remove('drag-over','dragging'));
}
function beginTaskDrag(e,task,row,text){
  if(e.button!==0||busy||loadFailed)return;const start={x:e.clientX,y:e.clientY};let active=false;
  text.setPointerCapture(e.pointerId);
  text.onpointermove=event=>{
    if(!active&&Math.hypot(event.clientX-start.x,event.clientY-start.y)<4)return;
    if(!active){active=true;dragged=task.id;const rect=row.getBoundingClientRect();const ghost=row.cloneNode(true);ghost.classList.add('drag-ghost');ghost.style.width=rect.width+'px';ghost.setAttribute('aria-hidden','true');document.body.append(ghost);row.classList.add('dragging');taskDrag={id:task.id,ghost,offsetX:start.x-rect.left,offsetY:start.y-rect.top,x:event.clientX,y:event.clientY,before:null,overTrash:false};tickDrag();}
    taskDrag.x=event.clientX;taskDrag.y=event.clientY;
  };
  text.onpointerup=()=>{text.onpointermove=null;text.onpointerup=null;if(!active)return;suppressClickUntil=performance.now()+400;const d=taskDrag;clearTaskDrag();if(!d)return;if(tab==='todo')void reorder(d.id,d.before);else if(d.overTrash)confirmDeletion(d.id);};
  text.onpointercancel=()=>{text.onpointermove=null;clearTaskDrag();};
  text.onlostpointercapture=()=>{if(taskDrag)clearTaskDrag();};
}
function tickDrag(){
  const d=taskDrag;if(!d)return;d.ghost.style.transform=`translate(${d.x-d.offsetX}px,${d.y-d.offsetY}px)`;
  const list=$('list'),bounds=list.getBoundingClientRect();if(d.y<bounds.top+28)list.scrollTop-=7;else if(d.y>bounds.bottom-28&&d.y<bounds.bottom+8)list.scrollTop+=7;
  document.querySelectorAll('.drag-over').forEach(e=>e.classList.remove('drag-over'));
  if(tab==='todo'){
    const rows=[...list.querySelectorAll('.row')].filter(r=>r.dataset.id!==d.id);d.before=model.dragTarget(d.y,rows.map(r=>({id:r.dataset.id,mid:r.getBoundingClientRect().top+r.getBoundingClientRect().height/2})));rows.find(r=>r.dataset.id===d.before)?.classList.add('drag-over');
  }else{const r=$('trash-target').getBoundingClientRect();d.overTrash=d.x>=r.left&&d.x<=r.right&&d.y>=r.top&&d.y<=r.bottom;$('trash-target').classList.toggle('targeted',d.overTrash);}
  d.raf=requestAnimationFrame(tickDrag);
}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&taskDrag){e.preventDefault();clearTaskDrag();}});
boot().catch(e=>{$('error').textContent=String(e);$('error').hidden=false;document.body.classList.add('expanded');$('panel').inert=false;});
