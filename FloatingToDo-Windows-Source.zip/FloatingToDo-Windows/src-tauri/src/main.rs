#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
mod storage;
use serde::{Deserialize,Serialize};
use std::sync::Mutex;
use tauri::{Emitter, Manager, menu::{Menu, MenuItem, CheckMenuItem}, tray::TrayIconBuilder};
use tauri_plugin_autostart::ManagerExt;
use storage::{Repository,Snapshot,Task};

#[tauri::command]
fn load_tasks(repo:tauri::State<Mutex<Repository>>)->Result<Snapshot,String>{repo.lock().map_err(|e|e.to_string())?.read()}
#[tauri::command]
fn save_tasks(tasks:Vec<Task>,revision:u64,repo:tauri::State<Mutex<Repository>>)->Result<Snapshot,String>{repo.lock().map_err(|e|e.to_string())?.save(tasks,revision)}
#[derive(Clone, Copy, Serialize, Deserialize)]
struct Point { x:f64,y:f64 }
#[derive(Serialize)]
struct Area { x:f64,y:f64,width:f64,height:f64 }
#[derive(Serialize)]
struct Geometry { anchor:Point, area:Area }
#[tauri::command]
fn geometry(window:tauri::WebviewWindow)->Result<Geometry,String>{
    let scale=window.scale_factor().map_err(|e|e.to_string())?;
    let position=window.outer_position().map_err(|e|e.to_string())?;
    let monitor=window.current_monitor().map_err(|e|e.to_string())?.or(window.primary_monitor().map_err(|e|e.to_string())?).ok_or("No display available")?;
    let work=monitor.work_area();
    Ok(Geometry { anchor:Point{x:position.x as f64/scale,y:position.y as f64/scale},area:Area{x:work.position.x as f64/scale,y:work.position.y as f64/scale,width:work.size.width as f64/scale,height:work.size.height as f64/scale} })
}
#[derive(Deserialize)]
struct Circle { x:f64, y:f64, r:f64 }
#[tauri::command]
fn set_frame(window:tauri::WebviewWindow,x:f64,y:f64,width:f64,height:f64,radius:f64,circles:Option<Vec<Circle>>)->Result<(),String>{
    if ![x,y,width,height,radius].iter().all(|n|n.is_finite()) || !(64.0..=1000.0).contains(&width) || !(64.0..=1000.0).contains(&height) {return Err("Invalid window bounds".into())}
    if circles.as_ref().is_some_and(|items| items.len()!=3 || items.iter().any(|c| ![c.x,c.y,c.r].iter().all(|n|n.is_finite()) || c.r<1.0 || c.x-c.r<0.0 || c.y-c.r<0.0 || c.x+c.r>width || c.y+c.r>height)) { return Err("Invalid circle bounds".into()); }
    window.set_size(tauri::LogicalSize::new(width,height)).map_err(|e|e.to_string())?;
    window.set_position(tauri::LogicalPosition::new(x,y)).map_err(|e|e.to_string())?;
    #[cfg(windows)] unsafe {
        use windows_sys::Win32::Graphics::Gdi::{CreateRoundRectRgn, CreateEllipticRgn, CreateRectRgn, CombineRgn, RGN_OR, DeleteObject, SetWindowRgn};
        let scale=window.scale_factor().map_err(|e|e.to_string())?;
        let hwnd=window.hwnd().map_err(|e|e.to_string())?.0;
        let region=if let Some(items)=circles {
            let union=CreateRectRgn(0,0,0,0);
            if union.is_null(){return Err("Could not create menu shape".into());}
            for c in items {
                let part=CreateEllipticRgn(((c.x-c.r)*scale).round() as i32,((c.y-c.r)*scale).round() as i32,((c.x+c.r)*scale).round() as i32+1,((c.y+c.r)*scale).round() as i32+1);
                if part.is_null(){DeleteObject(union);return Err("Could not create button shape".into());}
                let ok=CombineRgn(union,union,part,RGN_OR);DeleteObject(part);
                if ok==0{DeleteObject(union);return Err("Could not combine menu shape".into());}
            }
            union
        }else{CreateRoundRectRgn(0,0,(width*scale).round() as i32+1,(height*scale).round() as i32+1,(radius*2.0*scale).round() as i32,(radius*2.0*scale).round() as i32)};
        if !region.is_null() && SetWindowRgn(hwnd,region,1)==0 {DeleteObject(region);return Err("Could not update window shape".into())}
    }
    #[cfg(not(windows))] let _=(radius,circles);
    Ok(())
}
#[tauri::command]
fn start_drag(window:tauri::WebviewWindow)->Result<(),String>{window.start_dragging().map_err(|e|e.to_string())}
#[tauri::command]
fn show_widget(window:tauri::WebviewWindow)->Result<(),String>{window.show().map_err(|e|e.to_string())}
#[tauri::command]
fn save_anchor(app:tauri::AppHandle,point:Point)->Result<(),String>{
    if !point.x.is_finite() || !point.y.is_finite() {return Err("Invalid position".into())}
    let path=app.path().app_data_dir().map_err(|e|e.to_string())?.join("position.json");
    storage::atomic_write(&path,&serde_json::to_vec(&point).map_err(|e|e.to_string())?)
}
struct UiMenu { items:Vec<tauri::menu::MenuItem<tauri::Wry>>, launch:tauri::menu::CheckMenuItem<tauri::Wry> }
#[tauri::command]
fn set_language(menu:tauri::State<UiMenu>,chinese:bool)->Result<(),String>{
    let names=if chinese{["显示悬浮球","打开待办","重置位置","退出"]}else{["Show Widget","Open To-Do","Reset Position","Quit"]};
    for (item,name) in menu.items.iter().zip(names){item.set_text(name).map_err(|e|e.to_string())?;}
    menu.launch.set_text(if chinese{"开机启动"}else{"Launch at Login"}).map_err(|e|e.to_string())
}
#[tauri::command]
fn focus_window(window:tauri::WebviewWindow)->Result<(),String>{window.set_focus().map_err(|e|e.to_string())}
#[tauri::command]
fn quit_app(app:tauri::AppHandle){app.exit(0);}
fn main(){
    tauri::Builder::default()
        .plugin(tauri_plugin_single_instance::init(|app,_,_|{if let Some(w)=app.get_webview_window("main"){let _=w.show();let _=w.set_focus();let _=w.emit("open-panel",());}}))
        .plugin(tauri_plugin_autostart::Builder::new().build())
        .setup(|app|{
            let data=app.path().app_data_dir()?;
            let task_path=std::env::var_os("FLOATING_TODO_DATA_FILE").map(std::path::PathBuf::from).unwrap_or_else(||data.join("tasks.json"));
            app.manage(Mutex::new(Repository::open(task_path)));
            let w=app.get_webview_window("main").unwrap();
            if let Ok(bytes)=std::fs::read(data.join("position.json")) {if let Ok(point)=serde_json::from_slice::<Point>(&bytes){if point.x.is_finite() && point.y.is_finite(){let _=w.set_position(tauri::LogicalPosition::new(point.x,point.y));}}} else {w.center()?;}
            let show=MenuItem::with_id(app,"show","Show Widget",true,None::<&str>)?;
            let open=MenuItem::with_id(app,"open","Open To-Do",true,None::<&str>)?;
            let reset=MenuItem::with_id(app,"reset","Reset Position",true,None::<&str>)?;
            let launch=CheckMenuItem::with_id(app,"launch","Launch at Login",true,app.autolaunch().is_enabled().unwrap_or(false),None::<&str>)?;
            let quit=MenuItem::with_id(app,"quit","Quit",true,None::<&str>)?;
            app.manage(UiMenu{items:vec![show.clone(),open.clone(),reset.clone(),quit.clone()],launch:launch.clone()});
            let menu=Menu::with_items(app,&[&show,&open,&reset,&launch,&quit])?;
            TrayIconBuilder::new().icon(app.default_window_icon().unwrap().clone()).tooltip("Floating To-Do").menu(&menu).on_menu_event(move |app,event|{
                let Some(w)=app.get_webview_window("main") else{return};
                match event.id.as_ref(){
                    "quit"=>app.exit(0),
                    "show"=>{let _=w.show();let _=w.set_focus();},
                    "open"=>{let _=w.show();let _=w.set_focus();let _=w.emit("open-panel",());},
                    "reset"=>{let _=w.emit("reset-position",());let _=w.show();},
                    "launch"=>{
                        let result=app.autolaunch().is_enabled().and_then(|enabled|if enabled{app.autolaunch().disable()}else{app.autolaunch().enable()});
                        let _=launch.set_checked(app.autolaunch().is_enabled().unwrap_or(false));
                        if let Err(e)=result{let _=w.emit("app-error",e.to_string());}
                    },_=>{}
                }
            }).build(app)?;
            Ok(())
        })
        .on_window_event(|window,event|{if let tauri::WindowEvent::Focused(false)=event{let _=window.emit("window-blur",());}})
        .invoke_handler(tauri::generate_handler![set_language,focus_window,quit_app,load_tasks,save_tasks,geometry,set_frame,start_drag,show_widget,save_anchor])
        .run(tauri::generate_context!()).expect("Could not start Floating To-Do");
}
