use serde::{Deserialize, Serialize};
use std::{collections::HashSet, fs, io::Write, path::{Path, PathBuf}};

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Task {
    pub id: String, pub title: String, pub status: String, pub deadline: Option<i64>,
    pub created_at: i64, pub completed_at: Option<i64>, pub cancelled_at: Option<i64>, pub position: u32,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct Snapshot { pub version: u32, pub revision: u64, pub tasks: Vec<Task> }
impl Default for Snapshot { fn default()->Self { Self { version:1, revision:0, tasks:vec![] } } }
fn validate(snapshot:&Snapshot)->Result<(),String> {
    if snapshot.version!=1 { return Err("Unsupported saved-data version; original file preserved.".into()) }
    let mut ids=HashSet::new();
    for t in &snapshot.tasks {
        if t.id.is_empty() || !ids.insert(&t.id) || t.title.trim().is_empty() || !["todo","completed","cancelled"].contains(&t.status.as_str()) {
            return Err("Invalid task data; original file preserved.".into())
        }
    }
    Ok(())
}
pub fn atomic_write(path:&Path, bytes:&[u8])->Result<(),String> {
    let parent=path.parent().ok_or("Invalid storage path")?;
    fs::create_dir_all(parent).map_err(|e|e.to_string())?;
    let mut temp=tempfile::NamedTempFile::new_in(parent).map_err(|e|e.to_string())?;
    temp.write_all(bytes).map_err(|e|e.to_string())?;
    temp.as_file().sync_all().map_err(|e|e.to_string())?;
    temp.persist(path).map_err(|e|e.to_string())?;
    Ok(())
}
pub struct Repository { pub path:PathBuf, pub current:Snapshot, pub error:Option<String> }
impl Repository {
    pub fn open(path:PathBuf)->Self {
        let result = match fs::read(&path) {
            Ok(bytes)=>serde_json::from_slice::<Snapshot>(&bytes).map_err(|e|e.to_string()).and_then(|s| { validate(&s)?; Ok(s) }),
            Err(e) if e.kind()==std::io::ErrorKind::NotFound=>Ok(Snapshot::default()),
            Err(e)=>Err(e.to_string()),
        };
        match result { Ok(current)=>Self{path,current,error:None},Err(e)=>Self{path,current:Snapshot::default(),error:Some(format!("Could not read saved tasks. No changes will be written. {e}"))} }
    }
    pub fn read(&self)->Result<Snapshot,String> { if let Some(e)=&self.error {Err(e.clone())}else{Ok(self.current.clone())} }
    pub fn save(&mut self, tasks:Vec<Task>, revision:u64)->Result<Snapshot,String> {
        self.read()?;
        if revision!=self.current.revision {return Err("Tasks changed. Reopen the app before editing.".into())}
        let next=Snapshot{version:1,revision:revision.checked_add(1).ok_or("Revision overflow")?,tasks};
        validate(&next)?;
        atomic_write(&self.path,&serde_json::to_vec_pretty(&next).map_err(|e|e.to_string())?)?;
        self.current=next;
        self.read()
    }
}
#[cfg(test)] mod tests {
    use super::*;
    fn task()->Task {Task{id:"1".into(),title:"Keep".into(),status:"todo".into(),deadline:None,created_at:1,completed_at:None,cancelled_at:None,position:0}}
    #[test] fn roundtrip_and_stale_write(){ let dir=tempfile::tempdir().unwrap();let path=dir.path().join("tasks.json"); let mut r=Repository::open(path.clone());r.save(vec![task()],0).unwrap();assert!(r.save(vec![],0).is_err());assert_eq!(Repository::open(path).read().unwrap(),r.current); }
    #[test] fn corrupt_file_is_never_overwritten(){let dir=tempfile::tempdir().unwrap();let path=dir.path().join("tasks.json");fs::write(&path,b"broken").unwrap();let mut r=Repository::open(path.clone());assert!(r.save(vec![],0).is_err());assert_eq!(fs::read(path).unwrap(),b"broken");}
    #[test] fn failed_save_preserves_memory(){let dir=tempfile::tempdir().unwrap();let mut r=Repository::open(dir.path().join("tasks.json"));r.save(vec![task()],0).unwrap();let before=r.current.clone();r.path=dir.path().to_path_buf();assert!(r.save(vec![],1).is_err());assert_eq!(r.current,before);}
    #[test] fn validation_prevents_duplicates(){let dir=tempfile::tempdir().unwrap();let mut r=Repository::open(dir.path().join("tasks.json"));assert!(r.save(vec![task(),task()],0).is_err());assert_eq!(r.current.revision,0);}
    #[test] fn deletion_persists(){let dir=tempfile::tempdir().unwrap();let path=dir.path().join("tasks.json");let mut r=Repository::open(path.clone());r.save(vec![task()],0).unwrap();r.save(vec![],1).unwrap();assert!(Repository::open(path).read().unwrap().tasks.is_empty());}
}
