# Validation — 2026-10-27

## Passed locally

- Ten Node tests: title validation; create/edit; status transitions; restoration order/deadline retention; selective completed/cancelled deletion; protection of active/unselected/restored tasks; ordering; two-stage geometry; negative monitor origins and small work areas; exact return to the collapsed anchor.
- Five Rust tests: atomic round-trip persistence; stale revision rejection; corrupt-file preservation; write-failure rollback; duplicate task ID rejection; persisted removal.
- Tauri backend compiled and Rust tests executed on Apple Silicon macOS, using a project-local Rust toolchain. This is not evidence that a Windows installer has run.
- Browser preview interactions: create tasks; save a deadline with the minute wheel; complete; restore; cancel; archive selection; correct count in permanent-deletion confirmation; cancel confirmation without removing data.
- Courier New labels and long task titles visually inspected in a browser preview. Light and dark preview backgrounds inspected. Preview storage is isolated from real Mac task data.
- Windows ICO includes 16, 32, 64, 128 and 256 pixel representations, repackaged from the existing clean app-icon artwork. No font files included.

## Platform build status

A local `cargo check --target x86_64-pc-windows-msvc` resolved Windows dependencies but stopped at the Windows resource build step because this Mac lacks `llvm-rc`. It did not complete Windows compilation. The provided GitHub Actions workflow uses a Windows runner to compile/test and produce the NSIS installer.

## Still requires Windows verification

- Actual Windows executable/installer startup and uninstall.
- Window transparency, circular native hit region, resize animation timing, dragging, taskbar/tray behavior and recovery after disconnecting a display.
- Mixed-DPI monitor movement and all accessibility preference combinations.
- Launch at Login and WebView2 bootstrap installation.
- Actual GUI confirmation of permanent deletion (model and storage tests cover its logic; the live preview checked cancellation).
- No Windows signing certificate is configured.

## Subsequent Windows CI result

Windows trial build verified on 2026-10-27.

GitHub run: https://github.com/hmjzhhhh-bit/FloatingToDo-Windows/actions/runs/40609606172
Commit: 4421f3d59324a49b454d029f2375602069268397
Result: Success; Windows x64 optimized build and NSIS packaging completed.
Tests: 10 Node tests and 5 Rust tests passed on the Windows runner.
Downloaded artifact SHA-256 matched GitHub: f5ad7f8f33ba5075e1cebc6747bd5c6128ffbeb889b549535b6274ea99545d36

Not verified: interactive Windows desktop launch, installer UI, mixed-DPI monitor movement, native dragging/animation and launch at login. The installer is unsigned.

GitHub emitted an action-runtime Node 20 deprecation warning; the run completed successfully using its enforced Node 24 action runtime.

## 1.3.1 validation

14 JavaScript tests and 5 Rust storage tests pass locally. Browser preview verified language and 24-hour settings, quit confirmation, right-click actions, quick input and calendar, and saving a task with its deadline. New tests cover fourth-to-first sorting and radial bounds at monitor corners. Windows CI build is required for native validation; interactive Windows behavior remains unverified on this Mac.
