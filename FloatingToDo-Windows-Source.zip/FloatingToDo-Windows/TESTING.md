# Validation — 2026-10-27

## Passed locally

- Ten Node tests: title validation; create/edit; status transitions; restoration order/deadline retention; selective completed/cancelled deletion; protection of active/unselected/restored tasks; ordering; two-stage geometry; negative monitor origins and small work areas; exact return to the collapsed anchor.
- Five Rust tests: atomic round-trip persistence; stale revision rejection; corrupt-file preservation; write-failure rollback; duplicate task ID rejection; persisted removal.
- Tauri backend compiled and Rust tests executed on Apple Silicon macOS, using a project-local Rust toolchain. This is not evidence that a Windows installer has run.
- Browser preview interactions: create tasks; save a deadline with the minute wheel; complete; restore; cancel; archive selection; correct count in permanent-deletion confirmation; cancel confirmation without removing data.
- Courier New labels and long task titles visually inspected in a browser preview. Light and dark preview backgrounds inspected. Preview storage is isolated from real Mac task data.
- Windows ICO includes 16, 32, 64, 128 and 256 pixel representations, repackaged from the existing clean app-icon artwork. No font files included.

## Platform build status

A local `cargo check --target x86_64-pc-windows-msvc` resolved Windows dependencies but stopped at the Windows resource build step because this Mac lacks `llvm-rc`. It did not complete Windows compilation. The provided GitHub Actions workflow uses a Windows runner to compile/test and produce the NSIS installer.

## Still requires Windows verification

- Actual Windows executable/installer startup and uninstall.
- Window transparency, circular native hit region, resize animation timing, dragging, taskbar/tray behavior and recovery after disconnecting a display.
- Mixed-DPI monitor movement and all accessibility preference combinations.
- Launch at Login and WebView2 bootstrap installation.
- Actual GUI confirmation of permanent deletion (model and storage tests cover its logic; the live preview checked cancellation).
- No Windows signing certificate is configured.
